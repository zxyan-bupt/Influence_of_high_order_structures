clear all;
close all;
clc;

%模拟得到的和异质平均场得到的四种网络出现双稳态时所需的\lambda_\Delta

Simulation=[0.261,0.310,0.347,0.368];
HMF=[0.2407,0.2982,0.4076,0.4153];

figure(1)
hold on;
plot(0:1:3,Simulation,'k--', 'LineWidth', 1.5);
plot(0:1:3,HMF,'ko', 'MarkerSize', 8, 'LineWidth', 1.5);

box on;
axis([0 3 0.2 0.5]);
set(gca, 'FontName', 'Cambria Math'); % 设置字体
set(gca, 'FontSize', 12); % 设置字体大小
title('ERSC');
xlabel('Number of first-order edges in a triangle')
ylabel('\lambda^c_{\Delta}')
% xticks([3 3.5 4 4.5 5 5.5 6]); % 设置 x 轴刻度位置
% yticks([0.1 0.2 0.3 0.4]); % 设置 y 轴刻度位置
annotation('textbox', [0.02, 0.9, 0.1, 0.1], 'String', '(a)', 'FontName', 'Cambria Math', 'EdgeColor', 'none', 'BackgroundColor', 'none', 'FontSize', 15);
legend('Simulation','HMF','Location','northeast');