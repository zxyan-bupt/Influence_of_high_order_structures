clear all;
close all;
clc;

%每个网络出现双稳态的λΔ与<kΔ>的关系
%<kΔ>从3到6

lambda_delta_F3=[0.302,0.267,0.229,0.205,0.183,0.169,0.158];
lambda_delta_F2=[0.330,0.284,0.248,0.218,0.196,0.177,0.164];
lambda_delta_F1=[0.359,0.310,0.270,0.236,0.213,0.193,0.179];
lambda_delta_F0=[0.394,0.336,0.299,0.264,0.232,0.217,0.199];

figure(1)
hold on;
plot(3:0.5:6,lambda_delta_F0,'ko--');
plot(3:0.5:6,lambda_delta_F1,'go--');
plot(3:0.5:6,lambda_delta_F2,'bo--');
plot(3:0.5:6,lambda_delta_F3,'ro--');

box on;
axis([3 6 0.1 0.4]);
set(gca, 'FontName', 'Cambria Math'); % 设置字体
set(gca, 'FontSize', 12); % 设置字体大小
title('ERSC');
xlabel('<k_{\Delta}>')
ylabel('\lambda^c_{\Delta}')
% xlim([0.02 0.06]); % 设置x轴范围
% ylim([ymin ymax]); % 设置y轴范围
xticks([3 3.5 4 4.5 5 5.5 6]); % 设置 x 轴刻度位置
yticks([0.1 0.2 0.3 0.4]); % 设置 y 轴刻度位置
annotation('textbox', [0.02, 0.9, 0.1, 0.1], 'String', '(a)', 'FontName', 'Cambria Math', 'EdgeColor', 'none', 'BackgroundColor', 'none', 'FontSize', 15);
legend('0 first-order edges in a triangle','1 first-order edges in a triangle','2 first-order edges in a triangle','3 first-order edges in a triangle','Location','northeast');