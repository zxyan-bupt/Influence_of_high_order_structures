clear all;
close all;
clc;

%每个网络出现双稳态的λΔ与<kΔ>的关系
%<kΔ>从3到6

%F拟合,图的后缀是c
% lambda_delta_F3=[0.3054,0.2752,0.2319,0.2116,0.1885,0.1741,0.1605];
% lambda_delta_F2=[0.3322,0.2822,0.2449,0.2158,0.1966,0.1800,0.1621];
% lambda_delta_F1=[0.3340,0.2921,0.2601,0.2277,0.2024,0.1808,0.1767];
% lambda_delta_F0=[0.3543,0.2933,0.2662,0.2379,0.2087,0.1940,0.1776];

%F不拟合,图的后缀是c2
lambda_delta_F3=[0.3224,0.2773,0.2424,0.2149,0.1924,0.1759,0.1610];
lambda_delta_F2=[0.3309,0.2836,0.2474,0.2189,0.1958,0.1790,0.1631];
lambda_delta_F1=[0.3410,0.2920,0.2566,0.2250,0.2008,0.1834,0.1698];
lambda_delta_F0=[0.3509,0.2979,0.2643,0.2331,0.2068,0.1894,0.1734];

figure(1)
hold on;
plot(3:0.5:6,lambda_delta_F0,'ko--');
plot(3:0.5:6,lambda_delta_F1,'go--');
plot(3:0.5:6,lambda_delta_F2,'bo--');
plot(3:0.5:6,lambda_delta_F3,'ro--');

box on;
axis([3 6 0.1 0.4]);
set(gca, 'FontName', 'Cambria Math'); % 设置字体
set(gca, 'FontSize', 12); % 设置字体大小
title('ERSC');
xlabel('<k_{\Delta}>')
ylabel('\lambda^c_{\Delta}')
% xlim([0.02 0.06]); % 设置x轴范围
% ylim([ymin ymax]); % 设置y轴范围
xticks([3 3.5 4 4.5 5 5.5 6]); % 设置 x 轴刻度位置
yticks([0.1 0.2 0.3 0.4]); % 设置 y 轴刻度位置
annotation('textbox', [0.02, 0.9, 0.1, 0.1], 'String', '(a)', 'FontName', 'Cambria Math', 'EdgeColor', 'none', 'BackgroundColor', 'none', 'FontSize', 15);
legend('0 first-order edges in a triangle','1 first-order edges in a triangle','2 first-order edges in a triangle','3 first-order edges in a triangle','Location','northeast');