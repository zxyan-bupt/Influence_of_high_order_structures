clear all;
close all;
clc;

rho_plot_h0cl=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.665_h_cl.txt','\t');
rho_plot_h1cl=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.665_h_cl.txt','\t');
% rho_plot_h1cl=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.640_h_cl.txt','\t');
% rho_plot_h2cl=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.640_h_cl.txt','\t');
% rho_plot_h2cl=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.610_h_cl.txt','\t');
% rho_plot_h3cl=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.610_h_cl.txt','\t');

rho_plot_h0=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.665_h_x.txt','\t');
rho_plot_h1=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.665_h_x.txt','\t');
% rho_plot_h1=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.640_h_x.txt','\t');
% rho_plot_h2=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.640_h_x.txt','\t');
% rho_plot_h2=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.610_h_x.txt','\t');
% rho_plot_h3=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.610_h_x.txt','\t');

rho_plot_h0cr=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.665_h_cr.txt','\t');
rho_plot_h1cr=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.665_h_cr.txt','\t');
% rho_plot_h1cr=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.640_h_cr.txt','\t');
% rho_plot_h2cr=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.640_h_cr.txt','\t');
% rho_plot_h2cr=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.610_h_cr.txt','\t');
% rho_plot_h3cr=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.610_h_cr.txt','\t');

rho_plot_l0=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.665_l_x.txt','\t');
rho_plot_l1=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.665_l_x.txt','\t');
% rho_plot_l1=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.640_l_x.txt','\t');
% rho_plot_l2=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.640_l_x.txt','\t');
% rho_plot_l2=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.610_l_x.txt','\t');
% rho_plot_l3=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.610_l_x.txt','\t');


lambda1_plot0cl=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.665_lambda1_plot_cl.txt','\t');
lambda1_plot1cl=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.665_lambda1_plot_cl.txt','\t');
% lambda1_plot1cl=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.640_lambda1_plot_cl.txt','\t');
% lambda1_plot2cl=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.640_lambda1_plot_cl.txt','\t');
% lambda1_plot2cl=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.610_lambda1_plot_cl.txt','\t');
% lambda1_plot3cl=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.610_lambda1_plot_cl.txt','\t');

lambda1_plot0=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.665_lambda1_plot_x.txt','\t');
lambda1_plot1=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.665_lambda1_plot_x.txt','\t');
% lambda1_plot1=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.640_lambda1_plot_x.txt','\t');
% lambda1_plot2=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.640_lambda1_plot_x.txt','\t');
% lambda1_plot2=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.610_lambda1_plot_x.txt','\t');
% lambda1_plot3=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.610_lambda1_plot_x.txt','\t');

lambda1_plot0cr=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.665_lambda1_plot_cr.txt','\t');
lambda1_plot1cr=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.665_lambda1_plot_cr.txt','\t');
% lambda1_plot1cr=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.640_lambda1_plot_cr.txt','\t');
% lambda1_plot2cr=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.640_lambda1_plot_cr.txt','\t');
% lambda1_plot2cr=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.610_lambda1_plot_cr.txt','\t');
% lambda1_plot3cr=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.610_lambda1_plot_cr.txt','\t');

figure(1)
hold on;
plot(lambda1_plot0cl,rho_plot_h0cl,'k');
plot(lambda1_plot1cl,rho_plot_h1cl,'r');
% plot(lambda1_plot1cl,rho_plot_h1cl,'k');
% plot(lambda1_plot2cl,rho_plot_h2cl,'r');
% plot(lambda1_plot2cl,rho_plot_h2cl,'k');
% plot(lambda1_plot3cl,rho_plot_h3cl,'r');

plot(lambda1_plot0,rho_plot_h0,'k');
plot(lambda1_plot1,rho_plot_h1,'r');
% plot(lambda1_plot1,rho_plot_h1,'k');
% plot(lambda1_plot2,rho_plot_h2,'r');
% plot(lambda1_plot2,rho_plot_h2,'k');
% plot(lambda1_plot3,rho_plot_h3,'r');

plot(lambda1_plot0cr,rho_plot_h0cr,'k');
plot(lambda1_plot1cr,rho_plot_h1cr,'r');
% plot(lambda1_plot1cr,rho_plot_h1cr,'k');
% plot(lambda1_plot2cr,rho_plot_h2cr,'r');
% plot(lambda1_plot2cr,rho_plot_h2cr,'k');
% plot(lambda1_plot3cr,rho_plot_h3cr,'r');

plot(lambda1_plot0,rho_plot_l0,'k');
plot(lambda1_plot1,rho_plot_l1,'r');
% plot(lambda1_plot1,rho_plot_l1,'k');
% plot(lambda1_plot2,rho_plot_l2,'r');
% plot(lambda1_plot2,rho_plot_l2,'k');
% plot(lambda1_plot3,rho_plot_l3,'r');

box on;
axis([0.02 0.06 0 0.6]);
set(gca, 'FontName', 'Cambria Math'); % 设置字体
set(gca, 'FontSize', 12); % 设置字体大小
title('SFSC');
xlabel('\lambda')
ylabel('\rho(\infty)')
xticks([0.02 0.03 0.04 0.05 0.06]); % 设置 x 轴刻度位置
yticks([0 0.2 0.4 0.6]); % 设置 y 轴刻度位置
annotation('textbox', [0.02, 0.9, 0.1, 0.1], 'String', '(d)', 'FontName', 'Cambria Math', 'EdgeColor', 'none', 'BackgroundColor', 'none', 'FontSize', 15);
legend('k^2_{\Delta}=3','k^3_{\Delta}=3','Location','northwest','Box','off');

% 小图
axes('Position', [0.505, 0.2, 0.36, 0.36]); 
hold on;
plot(lambda1_plot0cl,rho_plot_h0cl,'k');
plot(lambda1_plot1cl,rho_plot_h1cl,'r');
% plot(lambda1_plot1cl,rho_plot_h1cl,'k');
% plot(lambda1_plot2cl,rho_plot_h2cl,'r');
% plot(lambda1_plot2cl,rho_plot_h2cl,'k');
% plot(lambda1_plot3cl,rho_plot_h3cl,'r');

plot(lambda1_plot0,rho_plot_h0,'k');
plot(lambda1_plot1,rho_plot_h1,'r');
% plot(lambda1_plot1,rho_plot_h1,'k');
% plot(lambda1_plot2,rho_plot_h2,'r');
% plot(lambda1_plot2,rho_plot_h2,'k');
% plot(lambda1_plot3,rho_plot_h3,'r');

plot(lambda1_plot0cr,rho_plot_h0cr,'k');
plot(lambda1_plot1cr,rho_plot_h1cr,'r');
% plot(lambda1_plot1cr,rho_plot_h1cr,'k');
% plot(lambda1_plot2cr,rho_plot_h2cr,'r');
% plot(lambda1_plot2cr,rho_plot_h2cr,'k');
% plot(lambda1_plot3cr,rho_plot_h3cr,'r');

plot(lambda1_plot0,rho_plot_l0,'k');
plot(lambda1_plot1,rho_plot_l1,'r');
% plot(lambda1_plot1,rho_plot_l1,'k');
% plot(lambda1_plot2,rho_plot_l2,'r');
% plot(lambda1_plot2,rho_plot_l2,'k');
% plot(lambda1_plot3,rho_plot_l3,'r');
box on;
axis([0.031 0.032 0 0.4]);
xlabel('\lambda')
ylabel('\rho(\infty)')
xticks([0.0310 0.0315 0.0320]); % 设置 x 轴刻度位置