figure(1)
hold on;
plot(lambda1_plot, rho_plot_h,'k');
plot(lambda1_plot, rho_plot_l,'r');