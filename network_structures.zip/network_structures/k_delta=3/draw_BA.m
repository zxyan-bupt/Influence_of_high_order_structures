clear all;
close all;
clc;

rho_plot_h0=load('BA_N=2000_k1=20_k01=3_ode_lambda_delta=0.71_h.txt','\t');
rho_plot_h1=load('BA_N=2000_k1=20_k11=3_ode_lambda_delta=0.71_h.txt','\t');
rho_plot_h2=load('BA_N=2000_k1=20_k21=3_ode_lambda_delta=0.71_h.txt','\t');
rho_plot_h3=load('BA_N=2000_k1=20_k31=3_ode_lambda_delta=0.71_h.txt','\t');

rho_plot_l0=load('BA_N=2000_k1=20_k01=3_ode_lambda_delta=0.71_l.txt','\t');
rho_plot_l1=load('BA_N=2000_k1=20_k11=3_ode_lambda_delta=0.71_l.txt','\t');
rho_plot_l2=load('BA_N=2000_k1=20_k21=3_ode_lambda_delta=0.71_l.txt','\t');
rho_plot_l3=load('BA_N=2000_k1=20_k31=3_ode_lambda_delta=0.71_l.txt','\t');


lambda1_plot0=load('BA_N=2000_k1=20_k01=3_ode_lambda_delta=0.71_lambda1_plot.txt','\t');
lambda1_plot1=load('BA_N=2000_k1=20_k11=3_ode_lambda_delta=0.71_lambda1_plot.txt','\t');
lambda1_plot2=load('BA_N=2000_k1=20_k21=3_ode_lambda_delta=0.71_lambda1_plot.txt','\t');
lambda1_plot3=load('BA_N=2000_k1=20_k31=3_ode_lambda_delta=0.71_lambda1_plot.txt','\t');

figure(1)
hold on;
plot(lambda1_plot0,rho_plot_h0,'k');
plot(lambda1_plot1,rho_plot_h1,'g');
plot(lambda1_plot2,rho_plot_h2,'b');
plot(lambda1_plot3,rho_plot_h3,'r');

plot(lambda1_plot0,rho_plot_l0,'k');
plot(lambda1_plot1,rho_plot_l1,'g');
plot(lambda1_plot2,rho_plot_l2,'b');
plot(lambda1_plot3,rho_plot_l3,'r');
xlabel('\lambda'), ylabel('I^*')
% legend('k^0=6','k^1=6','Location','northwest');
% legend('k^2=6','k^3=6','Location','northwest');
legend('k^0=6','k^1=6','k^2=6','k^3=6','Location','northwest');
% legend('k^0=6,下降阈值','k^0=6，上升阈值','k^3=6,下降阈值','k^3=6,上升阈值','Location','southeast');