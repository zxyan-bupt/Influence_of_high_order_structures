clear all;
close all;
clc;

load('N=2000_k1=20_k11=3_edge1_1.mat');
load('N=2000_k1=20_k11=3_edge2_1.mat');
load('N=2000_k1=20_k11=3_long_1.mat');

N=2000;
A=zeros(N,N);
k=zeros(1,N);
k_delta01=zeros(1,N);
k_delta11=zeros(1,N);
k_delta21=zeros(1,N);
k_delta31=zeros(1,N);
for i=1:long(1)
    for j=1:2
        k(edge1(i,j))=k(edge1(i,j))+1;
    end
    A(edge1(i,1),edge1(i,2))=1;
end
for i=1:long(2)
    panduan(i)=A(edge2(i,1),edge2(i,2))+A(edge2(i,1),edge2(i,3))+A(edge2(i,2),edge2(i,3));
    if panduan(i)==0
        for j=1:3
            k_delta01(edge2(i,j))=k_delta01(edge2(i,j))+1;
        end
    elseif panduan(i)==1
        for j=1:3
            k_delta11(edge2(i,j))=k_delta11(edge2(i,j))+1;
        end
    elseif panduan(i)==2
        for j=1:3
            k_delta21(edge2(i,j))=k_delta21(edge2(i,j))+1;
        end
    elseif panduan(i)==3
        for j=1:3
            k_delta31(edge2(i,j))=k_delta31(edge2(i,j))+1;
        end
    end
end

k_max=max(k);
k_delta_max=max(k_delta01+k_delta11+k_delta21+k_delta31);

for i=1:N
    Rg(i)=k(i)/k_max+( k_delta01(i)+k_delta11(i)+k_delta21(i)+k_delta31(i) )/k_delta_max;
end
[Rg_sort,i_sort]=sort(Rg);

i_important=0;
for i=1:N
    if Rg_sort(i)>1.6
        i_important=i_important+1;
    end
end

Rg_important_bar=mean(Rg_sort(N-100:N));