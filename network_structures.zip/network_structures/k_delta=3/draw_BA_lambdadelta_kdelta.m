clear all;
close all;
clc;

%每个网络出现双稳态的λΔ与<kΔ>的关系
%<kΔ>从3到6

lambda_delta_F3=[0.616,0.462,0.393,0.287];
lambda_delta_F2=[0.640,0.492,0.399,0.330];
lambda_delta_F1=[0.661,0.525,0.427,0.363];
lambda_delta_F0=[0.700,0.546,0.448,0.393];

figure(1)
hold on;
plot(3:6,lambda_delta_F0,'k');
plot(3:6,lambda_delta_F1,'g');
plot(3:6,lambda_delta_F2,'b');
plot(3:6,lambda_delta_F3,'r');

xlabel('<k\delta>'), ylabel('\lambda_\delta')
legend('k^0=6','k^1=6','k^2=6','k^3=6','Location','northeast');