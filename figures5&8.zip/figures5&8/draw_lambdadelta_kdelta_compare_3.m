clear all;
close all;
clc;

lambda_delta_F3_ode=[0.302,0.267,0.229,0.205,0.183,0.169,0.158];
lambda_delta_F2_ode=[0.330,0.284,0.248,0.218,0.196,0.177,0.164];
lambda_delta_F1_ode=[0.359,0.310,0.270,0.236,0.213,0.193,0.179];
lambda_delta_F0_ode=[0.394,0.336,0.299,0.264,0.232,0.217,0.199];

lambda_delta_F3_SF_ode=[0.575,0.491,0.435,0.383,0.330,0.299,0.261];
lambda_delta_F2_SF_ode=[0.623,0.544,0.473,0.421,0.381,0.341,0.310];
lambda_delta_F1_SF_ode=[0.646,0.578,0.505,0.455,0.404,0.375,0.347];
lambda_delta_F0_SF_ode=[0.673,0.599,0.530,0.478,0.437,0.400,0.368];

lambda_delta_F0_3=load('F0_k_delta=3_lambda_delta_c.txt','\t');
lambda_delta_F1_3=load('F1_k_delta=3_lambda_delta_c.txt','\t');
lambda_delta_F2_3=load('F2_k_delta=3_lambda_delta_c.txt','\t');
lambda_delta_F3_3=load('F3_k_delta=3_lambda_delta_c.txt','\t');
lambda_delta_F0(1,1)=mean(lambda_delta_F0_3);
lambda_delta_F1(1,1)=mean(lambda_delta_F1_3);
lambda_delta_F2(1,1)=mean(lambda_delta_F2_3);
lambda_delta_F3(1,1)=mean(lambda_delta_F3_3);
lambda_delta_F0_std(1,1)=std(lambda_delta_F0_3);
lambda_delta_F1_std(1,1)=std(lambda_delta_F1_3);
lambda_delta_F2_std(1,1)=std(lambda_delta_F2_3);
lambda_delta_F3_std(1,1)=std(lambda_delta_F3_3);

lambda_delta_F0_3_25=load('F0_k_delta=3_25_lambda_delta_c.txt','\t');
lambda_delta_F1_3_25=load('F1_k_delta=3_25_lambda_delta_c.txt','\t');
lambda_delta_F2_3_25=load('F2_k_delta=3_25_lambda_delta_c.txt','\t');
lambda_delta_F3_3_25=load('F3_k_delta=3_25_lambda_delta_c.txt','\t');
lambda_delta_F0(1,2)=mean(lambda_delta_F0_3_25);
lambda_delta_F1(1,2)=mean(lambda_delta_F1_3_25);
lambda_delta_F2(1,2)=mean(lambda_delta_F2_3_25);
lambda_delta_F3(1,2)=mean(lambda_delta_F3_3_25);
lambda_delta_F0_std(1,2)=std(lambda_delta_F0_3_25);
lambda_delta_F1_std(1,2)=std(lambda_delta_F1_3_25);
lambda_delta_F2_std(1,2)=std(lambda_delta_F2_3_25);
lambda_delta_F3_std(1,2)=std(lambda_delta_F3_3_25);

lambda_delta_F0_3_5=load('F0_k_delta=3_5_lambda_delta_c.txt','\t');
lambda_delta_F1_3_5=load('F1_k_delta=3_5_lambda_delta_c.txt','\t');
lambda_delta_F2_3_5=load('F2_k_delta=3_5_lambda_delta_c.txt','\t');
lambda_delta_F3_3_5=load('F3_k_delta=3_5_lambda_delta_c.txt','\t');
lambda_delta_F0(1,3)=mean(lambda_delta_F0_3_5);
lambda_delta_F1(1,3)=mean(lambda_delta_F1_3_5);
lambda_delta_F2(1,3)=mean(lambda_delta_F2_3_5);
lambda_delta_F3(1,3)=mean(lambda_delta_F3_3_5);
lambda_delta_F0_std(1,3)=std(lambda_delta_F0_3_5);
lambda_delta_F1_std(1,3)=std(lambda_delta_F1_3_5);
lambda_delta_F2_std(1,3)=std(lambda_delta_F2_3_5);
lambda_delta_F3_std(1,3)=std(lambda_delta_F3_3_5);

lambda_delta_F0_3_75=load('F0_k_delta=3_75_lambda_delta_c.txt','\t');
lambda_delta_F1_3_75=load('F1_k_delta=3_75_lambda_delta_c.txt','\t');
lambda_delta_F2_3_75=load('F2_k_delta=3_75_lambda_delta_c.txt','\t');
lambda_delta_F3_3_75=load('F3_k_delta=3_75_lambda_delta_c.txt','\t');
lambda_delta_F0(1,4)=mean(lambda_delta_F0_3_75);
lambda_delta_F1(1,4)=mean(lambda_delta_F1_3_75);
lambda_delta_F2(1,4)=mean(lambda_delta_F2_3_75);
lambda_delta_F3(1,4)=mean(lambda_delta_F3_3_75);
lambda_delta_F0_std(1,4)=std(lambda_delta_F0_3_75);
lambda_delta_F1_std(1,4)=std(lambda_delta_F1_3_75);
lambda_delta_F2_std(1,4)=std(lambda_delta_F2_3_75);
lambda_delta_F3_std(1,4)=std(lambda_delta_F3_3_75);

lambda_delta_F0_4=load('F0_k_delta=4_lambda_delta_c.txt','\t');
lambda_delta_F1_4=load('F1_k_delta=4_lambda_delta_c.txt','\t');
lambda_delta_F2_4=load('F2_k_delta=4_lambda_delta_c.txt','\t');
lambda_delta_F3_4=load('F3_k_delta=4_lambda_delta_c.txt','\t');
lambda_delta_F0(1,5)=mean(lambda_delta_F0_4);
lambda_delta_F1(1,5)=mean(lambda_delta_F1_4);
lambda_delta_F2(1,5)=mean(lambda_delta_F2_4);
lambda_delta_F3(1,5)=mean(lambda_delta_F3_4);
lambda_delta_F0_std(1,5)=std(lambda_delta_F0_4);
lambda_delta_F1_std(1,5)=std(lambda_delta_F1_4);
lambda_delta_F2_std(1,5)=std(lambda_delta_F2_4);
lambda_delta_F3_std(1,5)=std(lambda_delta_F3_4);

lambda_delta_F0_4_25=load('F0_k_delta=4_25_lambda_delta_c.txt','\t');
lambda_delta_F1_4_25=load('F1_k_delta=4_25_lambda_delta_c.txt','\t');
lambda_delta_F2_4_25=load('F2_k_delta=4_25_lambda_delta_c.txt','\t');
lambda_delta_F3_4_25=load('F3_k_delta=4_25_lambda_delta_c.txt','\t');
lambda_delta_F0(1,6)=mean(lambda_delta_F0_4_25);
lambda_delta_F1(1,6)=mean(lambda_delta_F1_4_25);
lambda_delta_F2(1,6)=mean(lambda_delta_F2_4_25);
lambda_delta_F3(1,6)=mean(lambda_delta_F3_4_25);
lambda_delta_F0_std(1,6)=std(lambda_delta_F0_4_25);
lambda_delta_F1_std(1,6)=std(lambda_delta_F1_4_25);
lambda_delta_F2_std(1,6)=std(lambda_delta_F2_4_25);
lambda_delta_F3_std(1,6)=std(lambda_delta_F3_4_25);

lambda_delta_F0_4_5=load('F0_k_delta=4_5_lambda_delta_c.txt','\t');
lambda_delta_F1_4_5=load('F1_k_delta=4_5_lambda_delta_c.txt','\t');
lambda_delta_F2_4_5=load('F2_k_delta=4_5_lambda_delta_c.txt','\t');
lambda_delta_F3_4_5=load('F3_k_delta=4_5_lambda_delta_c.txt','\t');
lambda_delta_F0(1,7)=mean(lambda_delta_F0_4_5);
lambda_delta_F1(1,7)=mean(lambda_delta_F1_4_5);
lambda_delta_F2(1,7)=mean(lambda_delta_F2_4_5);
lambda_delta_F3(1,7)=mean(lambda_delta_F3_4_5);
lambda_delta_F0_std(1,7)=std(lambda_delta_F0_4_5);
lambda_delta_F1_std(1,7)=std(lambda_delta_F1_4_5);
lambda_delta_F2_std(1,7)=std(lambda_delta_F2_4_5);
lambda_delta_F3_std(1,7)=std(lambda_delta_F3_4_5);

lambda_delta_F0_4_75=load('F0_k_delta=4_75_lambda_delta_c.txt','\t');
lambda_delta_F1_4_75=load('F1_k_delta=4_75_lambda_delta_c.txt','\t');
lambda_delta_F2_4_75=load('F2_k_delta=4_75_lambda_delta_c.txt','\t');
lambda_delta_F3_4_75=load('F3_k_delta=4_75_lambda_delta_c.txt','\t');
lambda_delta_F0(1,8)=mean(lambda_delta_F0_4_75);
lambda_delta_F1(1,8)=mean(lambda_delta_F1_4_75);
lambda_delta_F2(1,8)=mean(lambda_delta_F2_4_75);
lambda_delta_F3(1,8)=mean(lambda_delta_F3_4_75);
lambda_delta_F0_std(1,8)=std(lambda_delta_F0_4_75);
lambda_delta_F1_std(1,8)=std(lambda_delta_F1_4_75);
lambda_delta_F2_std(1,8)=std(lambda_delta_F2_4_75);
lambda_delta_F3_std(1,8)=std(lambda_delta_F3_4_75);

lambda_delta_F0_5=load('F0_k_delta=5_lambda_delta_c.txt','\t');
lambda_delta_F1_5=load('F1_k_delta=5_lambda_delta_c.txt','\t');
lambda_delta_F2_5=load('F2_k_delta=5_lambda_delta_c.txt','\t');
lambda_delta_F3_5=load('F3_k_delta=5_lambda_delta_c.txt','\t');
lambda_delta_F0(1,9)=mean(lambda_delta_F0_5);
lambda_delta_F1(1,9)=mean(lambda_delta_F1_5);
lambda_delta_F2(1,9)=mean(lambda_delta_F2_5);
lambda_delta_F3(1,9)=mean(lambda_delta_F3_5);
lambda_delta_F0_std(1,9)=std(lambda_delta_F0_5);
lambda_delta_F1_std(1,9)=std(lambda_delta_F1_5);
lambda_delta_F2_std(1,9)=std(lambda_delta_F2_5);
lambda_delta_F3_std(1,9)=std(lambda_delta_F3_5);

lambda_delta_F0_5_25=load('F0_k_delta=5_25_lambda_delta_c.txt','\t');
lambda_delta_F1_5_25=load('F1_k_delta=5_25_lambda_delta_c.txt','\t');
lambda_delta_F2_5_25=load('F2_k_delta=5_25_lambda_delta_c.txt','\t');
lambda_delta_F3_5_25=load('F3_k_delta=5_25_lambda_delta_c.txt','\t');
lambda_delta_F0(1,10)=mean(lambda_delta_F0_5_25);
lambda_delta_F1(1,10)=mean(lambda_delta_F1_5_25);
lambda_delta_F2(1,10)=mean(lambda_delta_F2_5_25);
lambda_delta_F3(1,10)=mean(lambda_delta_F3_5_25);
lambda_delta_F0_std(1,10)=std(lambda_delta_F0_5_25);
lambda_delta_F1_std(1,10)=std(lambda_delta_F1_5_25);
lambda_delta_F2_std(1,10)=std(lambda_delta_F2_5_25);
lambda_delta_F3_std(1,10)=std(lambda_delta_F3_5_25);

lambda_delta_F0_5_5=load('F0_k_delta=5_5_lambda_delta_c.txt','\t');
lambda_delta_F1_5_5=load('F1_k_delta=5_5_lambda_delta_c.txt','\t');
lambda_delta_F2_5_5=load('F2_k_delta=5_5_lambda_delta_c.txt','\t');
lambda_delta_F3_5_5=load('F3_k_delta=5_5_lambda_delta_c.txt','\t');
lambda_delta_F0(1,11)=mean(lambda_delta_F0_5_5);
lambda_delta_F1(1,11)=mean(lambda_delta_F1_5_5);
lambda_delta_F2(1,11)=mean(lambda_delta_F2_5_5);
lambda_delta_F3(1,11)=mean(lambda_delta_F3_5_5);
lambda_delta_F0_std(1,11)=std(lambda_delta_F0_5_5);
lambda_delta_F1_std(1,11)=std(lambda_delta_F1_5_5);
lambda_delta_F2_std(1,11)=std(lambda_delta_F2_5_5);
lambda_delta_F3_std(1,11)=std(lambda_delta_F3_5_5);

lambda_delta_F0_5_75=load('F0_k_delta=5_75_lambda_delta_c.txt','\t');
lambda_delta_F1_5_75=load('F1_k_delta=5_75_lambda_delta_c.txt','\t');
lambda_delta_F2_5_75=load('F2_k_delta=5_75_lambda_delta_c.txt','\t');
lambda_delta_F3_5_75=load('F3_k_delta=5_75_lambda_delta_c.txt','\t');
lambda_delta_F0(1,12)=mean(lambda_delta_F0_5_75);
lambda_delta_F1(1,12)=mean(lambda_delta_F1_5_75);
lambda_delta_F2(1,12)=mean(lambda_delta_F2_5_75);
lambda_delta_F3(1,12)=mean(lambda_delta_F3_5_75);
lambda_delta_F0_std(1,12)=std(lambda_delta_F0_5_75);
lambda_delta_F1_std(1,12)=std(lambda_delta_F1_5_75);
lambda_delta_F2_std(1,12)=std(lambda_delta_F2_5_75);
lambda_delta_F3_std(1,12)=std(lambda_delta_F3_5_75);

lambda_delta_F0_6=load('F0_k_delta=6_lambda_delta_c.txt','\t');
lambda_delta_F1_6=load('F1_k_delta=6_lambda_delta_c.txt','\t');
lambda_delta_F2_6=load('F2_k_delta=6_lambda_delta_c.txt','\t');
lambda_delta_F3_6=load('F3_k_delta=6_lambda_delta_c.txt','\t');
lambda_delta_F0(1,13)=mean(lambda_delta_F0_6);
lambda_delta_F1(1,13)=mean(lambda_delta_F1_6);
lambda_delta_F2(1,13)=mean(lambda_delta_F2_6);
lambda_delta_F3(1,13)=mean(lambda_delta_F3_6);
lambda_delta_F0_std(1,13)=std(lambda_delta_F0_6);
lambda_delta_F1_std(1,13)=std(lambda_delta_F1_6);
lambda_delta_F2_std(1,13)=std(lambda_delta_F2_6);
lambda_delta_F3_std(1,13)=std(lambda_delta_F3_6);

lambda_delta_F3=[0.3224,0.2987,0.2773,0.2558,0.2424,0.2279,0.2149,0.2039,0.1924,0.1864,0.1759,0.1686,0.1610];
lambda_delta_F2=[0.3309,0.3035,0.2836,0.2643,0.2474,0.2292,0.2189,0.2085,0.1958,0.1889,0.1790,0.1716,0.1631];
lambda_delta_F1=[0.3410,0.3106,0.2920,0.2679,0.2566,0.2389,0.2250,0.2134,0.2008,0.1916,0.1834,0.1747,0.1698];
lambda_delta_F0=[0.3509,0.3202,0.2979,0.2806,0.2643,0.2442,0.2331,0.2197,0.2068,0.1980,0.1894,0.1819,0.1734];

lambda_delta_F0_SF_3=load('SF_F0_k_delta=3_lambda_delta_c.txt','\t');
lambda_delta_F1_SF_3=load('SF_F1_k_delta=3_lambda_delta_c.txt','\t');
lambda_delta_F2_SF_3=load('SF_F2_k_delta=3_lambda_delta_c.txt','\t');
lambda_delta_F3_SF_3=load('SF_F3_k_delta=3_lambda_delta_c.txt','\t');
lambda_delta_F0_SF(1,1)=mean(lambda_delta_F0_SF_3);
lambda_delta_F1_SF(1,1)=mean(lambda_delta_F1_SF_3);
lambda_delta_F2_SF(1,1)=mean(lambda_delta_F2_SF_3);
lambda_delta_F3_SF(1,1)=mean(lambda_delta_F3_SF_3);
lambda_delta_F0_SF_std(1,1)=std(lambda_delta_F0_SF_3);
lambda_delta_F1_SF_std(1,1)=std(lambda_delta_F1_SF_3);
lambda_delta_F2_SF_std(1,1)=std(lambda_delta_F2_SF_3);
lambda_delta_F3_SF_std(1,1)=std(lambda_delta_F3_SF_3);

lambda_delta_F0_SF_3_25=load('SF_F0_k_delta=3_25_lambda_delta_c.txt','\t');
lambda_delta_F1_SF_3_25=load('SF_F1_k_delta=3_25_lambda_delta_c.txt','\t');
lambda_delta_F2_SF_3_25=load('SF_F2_k_delta=3_25_lambda_delta_c.txt','\t');
lambda_delta_F3_SF_3_25=load('SF_F3_k_delta=3_25_lambda_delta_c.txt','\t');
lambda_delta_F0_SF(1,2)=mean(lambda_delta_F0_SF_3_25);
lambda_delta_F1_SF(1,2)=mean(lambda_delta_F1_SF_3_25);
lambda_delta_F2_SF(1,2)=mean(lambda_delta_F2_SF_3_25);
lambda_delta_F3_SF(1,2)=mean(lambda_delta_F3_SF_3_25);
lambda_delta_F0_SF_std(1,2)=std(lambda_delta_F0_SF_3_25);
lambda_delta_F1_SF_std(1,2)=std(lambda_delta_F1_SF_3_25);
lambda_delta_F2_SF_std(1,2)=std(lambda_delta_F2_SF_3_25);
lambda_delta_F3_SF_std(1,2)=std(lambda_delta_F3_SF_3_25);

lambda_delta_F0_SF_3_5=load('SF_F0_k_delta=3_5_lambda_delta_c.txt','\t');
lambda_delta_F1_SF_3_5=load('SF_F1_k_delta=3_5_lambda_delta_c.txt','\t');
lambda_delta_F2_SF_3_5=load('SF_F2_k_delta=3_5_lambda_delta_c.txt','\t');
lambda_delta_F3_SF_3_5=load('SF_F3_k_delta=3_5_lambda_delta_c.txt','\t');
lambda_delta_F0_SF(1,3)=mean(lambda_delta_F0_SF_3_5);
lambda_delta_F1_SF(1,3)=mean(lambda_delta_F1_SF_3_5);
lambda_delta_F2_SF(1,3)=mean(lambda_delta_F2_SF_3_5);
lambda_delta_F3_SF(1,3)=mean(lambda_delta_F3_SF_3_5);
lambda_delta_F0_SF_std(1,3)=std(lambda_delta_F0_SF_3_5);
lambda_delta_F1_SF_std(1,3)=std(lambda_delta_F1_SF_3_5);
lambda_delta_F2_SF_std(1,3)=std(lambda_delta_F2_SF_3_5);
lambda_delta_F3_SF_std(1,3)=std(lambda_delta_F3_SF_3_5);

lambda_delta_F0_SF_3_75=load('SF_F0_k_delta=3_75_lambda_delta_c.txt','\t');
lambda_delta_F1_SF_3_75=load('SF_F1_k_delta=3_75_lambda_delta_c.txt','\t');
lambda_delta_F2_SF_3_75=load('SF_F2_k_delta=3_75_lambda_delta_c.txt','\t');
lambda_delta_F3_SF_3_75=load('SF_F3_k_delta=3_75_lambda_delta_c.txt','\t');
lambda_delta_F0_SF(1,4)=mean(lambda_delta_F0_SF_3_75);
lambda_delta_F1_SF(1,4)=mean(lambda_delta_F1_SF_3_75);
lambda_delta_F2_SF(1,4)=mean(lambda_delta_F2_SF_3_75);
lambda_delta_F3_SF(1,4)=mean(lambda_delta_F3_SF_3_75);
lambda_delta_F0_SF_std(1,4)=std(lambda_delta_F0_SF_3_75);
lambda_delta_F1_SF_std(1,4)=std(lambda_delta_F1_SF_3_75);
lambda_delta_F2_SF_std(1,4)=std(lambda_delta_F2_SF_3_75);
lambda_delta_F3_SF_std(1,4)=std(lambda_delta_F3_SF_3_75);

lambda_delta_F0_SF_4=load('SF_F0_k_delta=4_lambda_delta_c.txt','\t');
lambda_delta_F1_SF_4=load('SF_F1_k_delta=4_lambda_delta_c.txt','\t');
lambda_delta_F2_SF_4=load('SF_F2_k_delta=4_lambda_delta_c.txt','\t');
lambda_delta_F3_SF_4=load('SF_F3_k_delta=4_lambda_delta_c.txt','\t');
lambda_delta_F0_SF(1,5)=mean(lambda_delta_F0_SF_4);
lambda_delta_F1_SF(1,5)=mean(lambda_delta_F1_SF_4);
lambda_delta_F2_SF(1,5)=mean(lambda_delta_F2_SF_4);
lambda_delta_F3_SF(1,5)=mean(lambda_delta_F3_SF_4);
lambda_delta_F0_SF_std(1,5)=std(lambda_delta_F0_SF_4);
lambda_delta_F1_SF_std(1,5)=std(lambda_delta_F1_SF_4);
lambda_delta_F2_SF_std(1,5)=std(lambda_delta_F2_SF_4);
lambda_delta_F3_SF_std(1,5)=std(lambda_delta_F3_SF_4);

lambda_delta_F0_SF_4_25=load('SF_F0_k_delta=4_25_lambda_delta_c.txt','\t');
lambda_delta_F1_SF_4_25=load('SF_F1_k_delta=4_25_lambda_delta_c.txt','\t');
lambda_delta_F2_SF_4_25=load('SF_F2_k_delta=4_25_lambda_delta_c.txt','\t');
lambda_delta_F3_SF_4_25=load('SF_F3_k_delta=4_25_lambda_delta_c.txt','\t');
lambda_delta_F0_SF(1,6)=mean(lambda_delta_F0_SF_4_25);
lambda_delta_F1_SF(1,6)=mean(lambda_delta_F1_SF_4_25);
lambda_delta_F2_SF(1,6)=mean(lambda_delta_F2_SF_4_25);
lambda_delta_F3_SF(1,6)=mean(lambda_delta_F3_SF_4_25);
lambda_delta_F0_SF_std(1,6)=std(lambda_delta_F0_SF_4_25);
lambda_delta_F1_SF_std(1,6)=std(lambda_delta_F1_SF_4_25);
lambda_delta_F2_SF_std(1,6)=std(lambda_delta_F2_SF_4_25);
lambda_delta_F3_SF_std(1,6)=std(lambda_delta_F3_SF_4_25);

lambda_delta_F0_SF_4_5=load('SF_F0_k_delta=4_5_lambda_delta_c.txt','\t');
lambda_delta_F1_SF_4_5=load('SF_F1_k_delta=4_5_lambda_delta_c.txt','\t');
lambda_delta_F2_SF_4_5=load('SF_F2_k_delta=4_5_lambda_delta_c.txt','\t');
lambda_delta_F3_SF_4_5=load('SF_F3_k_delta=4_5_lambda_delta_c.txt','\t');
lambda_delta_F0_SF(1,7)=mean(lambda_delta_F0_SF_4_5);
lambda_delta_F1_SF(1,7)=mean(lambda_delta_F1_SF_4_5);
lambda_delta_F2_SF(1,7)=mean(lambda_delta_F2_SF_4_5);
lambda_delta_F3_SF(1,7)=mean(lambda_delta_F3_SF_4_5);
lambda_delta_F0_SF_std(1,7)=std(lambda_delta_F0_SF_4_5);
lambda_delta_F1_SF_std(1,7)=std(lambda_delta_F1_SF_4_5);
lambda_delta_F2_SF_std(1,7)=std(lambda_delta_F2_SF_4_5);
lambda_delta_F3_SF_std(1,7)=std(lambda_delta_F3_SF_4_5);

lambda_delta_F0_SF_4_75=load('SF_F0_k_delta=4_75_lambda_delta_c.txt','\t');
lambda_delta_F1_SF_4_75=load('SF_F1_k_delta=4_75_lambda_delta_c.txt','\t');
lambda_delta_F2_SF_4_75=load('SF_F2_k_delta=4_75_lambda_delta_c.txt','\t');
lambda_delta_F3_SF_4_75=load('SF_F3_k_delta=4_75_lambda_delta_c.txt','\t');
lambda_delta_F0_SF(1,8)=mean(lambda_delta_F0_SF_4_75);
lambda_delta_F1_SF(1,8)=mean(lambda_delta_F1_SF_4_75);
lambda_delta_F2_SF(1,8)=mean(lambda_delta_F2_SF_4_75);
lambda_delta_F3_SF(1,8)=mean(lambda_delta_F3_SF_4_75);
lambda_delta_F0_SF_std(1,8)=std(lambda_delta_F0_SF_4_75);
lambda_delta_F1_SF_std(1,8)=std(lambda_delta_F1_SF_4_75);
lambda_delta_F2_SF_std(1,8)=std(lambda_delta_F2_SF_4_75);
lambda_delta_F3_SF_std(1,8)=std(lambda_delta_F3_SF_4_75);

lambda_delta_F0_SF_5=load('SF_F0_k_delta=5_lambda_delta_c.txt','\t');
lambda_delta_F1_SF_5=load('SF_F1_k_delta=5_lambda_delta_c.txt','\t');
lambda_delta_F2_SF_5=load('SF_F2_k_delta=5_lambda_delta_c.txt','\t');
lambda_delta_F3_SF_5=load('SF_F3_k_delta=5_lambda_delta_c.txt','\t');
lambda_delta_F0_SF(1,9)=mean(lambda_delta_F0_SF_5);
lambda_delta_F1_SF(1,9)=mean(lambda_delta_F1_SF_5);
lambda_delta_F2_SF(1,9)=mean(lambda_delta_F2_SF_5);
lambda_delta_F3_SF(1,9)=mean(lambda_delta_F3_SF_5);
lambda_delta_F0_SF_std(1,9)=std(lambda_delta_F0_SF_5);
lambda_delta_F1_SF_std(1,9)=std(lambda_delta_F1_SF_5);
lambda_delta_F2_SF_std(1,9)=std(lambda_delta_F2_SF_5);
lambda_delta_F3_SF_std(1,9)=std(lambda_delta_F3_SF_5);

lambda_delta_F0_SF_5_25=load('SF_F0_k_delta=5_25_lambda_delta_c.txt','\t');
lambda_delta_F1_SF_5_25=load('SF_F1_k_delta=5_25_lambda_delta_c.txt','\t');
lambda_delta_F2_SF_5_25=load('SF_F2_k_delta=5_25_lambda_delta_c.txt','\t');
lambda_delta_F3_SF_5_25=load('SF_F3_k_delta=5_25_lambda_delta_c.txt','\t');
lambda_delta_F0_SF(1,10)=mean(lambda_delta_F0_SF_5_25);
lambda_delta_F1_SF(1,10)=mean(lambda_delta_F1_SF_5_25);
lambda_delta_F2_SF(1,10)=mean(lambda_delta_F2_SF_5_25);
lambda_delta_F3_SF(1,10)=mean(lambda_delta_F3_SF_5_25);
lambda_delta_F0_SF_std(1,10)=std(lambda_delta_F0_SF_5_25);
lambda_delta_F1_SF_std(1,10)=std(lambda_delta_F1_SF_5_25);
lambda_delta_F2_SF_std(1,10)=std(lambda_delta_F2_SF_5_25);
lambda_delta_F3_SF_std(1,10)=std(lambda_delta_F3_SF_5_25);

lambda_delta_F0_SF_5_5=load('SF_F0_k_delta=5_5_lambda_delta_c.txt','\t');
lambda_delta_F1_SF_5_5=load('vF1_k_delta=5_5_lambda_delta_c.txt','\t');
lambda_delta_F2_SF_5_5=load('SF_F2_k_delta=5_5_lambda_delta_c.txt','\t');
lambda_delta_F3_SF_5_5=load('SF_F3_k_delta=5_5_lambda_delta_c.txt','\t');
lambda_delta_F0_SF(1,11)=mean(lambda_delta_F0_SF_5_5);
lambda_delta_F1_SF(1,11)=mean(lambda_delta_F1_SF_5_5);
lambda_delta_F2_SF(1,11)=mean(lambda_delta_F2_SF_5_5);
lambda_delta_F3_SF(1,11)=mean(lambda_delta_F3_SF_5_5);
lambda_delta_F0_SF_std(1,11)=std(lambda_delta_F0_SF_5_5);
lambda_delta_F1_SF_std(1,11)=std(lambda_delta_F1_SF_5_5);
lambda_delta_F2_SF_std(1,11)=std(lambda_delta_F2_SF_5_5);
lambda_delta_F3_SF_std(1,11)=std(lambda_delta_F3_SF_5_5);

lambda_delta_F0_SF_5_75=load('SF_F0_k_delta=5_75_lambda_delta_c.txt','\t');
lambda_delta_F1_SF_5_75=load('SF_F1_k_delta=5_75_lambda_delta_c.txt','\t');
lambda_delta_F2_SF_5_75=load('SF_F2_k_delta=5_75_lambda_delta_c.txt','\t');
lambda_delta_F3_SF_5_75=load('SF_F3_k_delta=5_75_lambda_delta_c.txt','\t');
lambda_delta_F0_SF(1,12)=mean(lambda_delta_F0_SF_5_75);
lambda_delta_F1_SF(1,12)=mean(lambda_delta_F1_SF_5_75);
lambda_delta_F2_SF(1,12)=mean(lambda_delta_F2_SF_5_75);
lambda_delta_F3_SF(1,12)=mean(lambda_delta_F3_SF_5_75);
lambda_delta_F0_SF_std(1,12)=std(lambda_delta_F0_SF_5_75);
lambda_delta_F1_SF_std(1,12)=std(lambda_delta_F1_SF_5_75);
lambda_delta_F2_SF_std(1,12)=std(lambda_delta_F2_SF_5_75);
lambda_delta_F3_SF_std(1,12)=std(lambda_delta_F3_SF_5_75);

lambda_delta_F0_SF_6=load('SF_F0_k_delta=6_lambda_delta_c.txt','\t');
lambda_delta_F1_SF_6=load('SF_F1_k_delta=6_lambda_delta_c.txt','\t');
lambda_delta_F2_SF_6=load('SF_F2_k_delta=6_lambda_delta_c.txt','\t');
lambda_delta_F3_SF_6=load('SF_F3_k_delta=6_lambda_delta_c.txt','\t');
lambda_delta_F0_SF(1,13)=mean(lambda_delta_F0_SF_6);
lambda_delta_F1_SF(1,13)=mean(lambda_delta_F1_SF_6);
lambda_delta_F2_SF(1,13)=mean(lambda_delta_F2_SF_6);
lambda_delta_F3_SF(1,13)=mean(lambda_delta_F3_SF_6);
lambda_delta_F0_SF_std(1,13)=std(lambda_delta_F0_SF_6);
lambda_delta_F1_SF_std(1,13)=std(lambda_delta_F1_SF_6);
lambda_delta_F2_SF_std(1,13)=std(lambda_delta_F2_SF_6);
lambda_delta_F3_SF_std(1,13)=std(lambda_delta_F3_SF_6);

% lambda_delta_F3_SF=[0.6380,0.5896,0.5375,0.4896,      ,0.4176,0.3840,0.3624,0.3393,0.3057,0.2872,0.2704,0.2490];
% lambda_delta_F2_SF=[0.6969,0.6405,0.5919,0.5478,0.5073,0.4755,0.4558,0.4124,0.3944,0.3657,0.3529.0.3306,0.3166];
% lambda_delta_F1_SF=[0.7566,0.6899,0.6443,0.5992,0.5563,0.5192,0.4890,0.4590,0.4370,0.4177,0.4033,0.3792,0.3662];
% lambda_delta_F0_SF=[0.7950,0.7277,0.6832,0.6334,0.5863,0.5578,0.5259,0.4998,0.4762,0.4489,      ,0.4124,0.3934];

figure('Position', [100, 100, 1600, 600]);

ax1=subplot(2, 4, 1);
hold on;
h1=plot(3:0.25:6,lambda_delta_F0,'r-','LineWidth',2,'MarkerSize',10,'DisplayName', 'HMF');
h2=plot(3:0.5:6,lambda_delta_F0_ode,'bo','LineWidth',2,'MarkerSize',10,'DisplayName', 'Numerical\newlinesimulation');
box on;
set(gca, 'FontName', 'Cambria Math'); % 设置字体
set(gca, 'FontSize', 18); % 设置字体大小
set(gca, 'LineWidth', 1); % 设置边框大小
title('(a) type-0','FontSize',18);
axis([3 6 0.1 0.4]);
xlabel('\langlek_{\Delta}\rangle'), ylabel('\lambda^c_{\Delta}')
% legend('HMF','Numerical simulation','Location','southwest','FontSize',10,'Box','off');

ax2=subplot(2, 4, 2);
plot(3:0.25:6,lambda_delta_F1,'r-',3:0.5:6,lambda_delta_F1_ode,'bo','LineWidth',2,'MarkerSize',10);
box on;
set(gca, 'FontName', 'Cambria Math'); % 设置字体
set(gca, 'FontSize', 18); % 设置字体大小
set(gca, 'LineWidth', 1); % 设置边框大小
title('(b) type-1','FontSize',18);
axis([3 6 0.1 0.4]);
xlabel('\langlek_{\Delta}\rangle'), ylabel('\lambda^c_{\Delta}')
% legend('HMF','Numerical simulation','Location','southwest','FontSize',10,'Box','off');

ax3=subplot(2, 4, 3);
plot(3:0.25:6,lambda_delta_F2,'r-',3:0.5:6,lambda_delta_F2_ode,'bo','LineWidth',2,'MarkerSize',10);
box on;
set(gca, 'FontName', 'Cambria Math'); % 设置字体
set(gca, 'FontSize', 18); % 设置字体大小
set(gca, 'LineWidth', 1); % 设置边框大小
title('(c) type-2','FontSize',18);
axis([3 6 0.1 0.4]);
xlabel('\langlek_{\Delta}\rangle'), ylabel('\lambda^c_{\Delta}')
% legend('HMF','Numerical simulation','Location','northeast','FontSize',10,'Box','off');

ax4=subplot(2, 4, 4);
plot(3:0.25:6,lambda_delta_F3,'r-',3:0.5:6,lambda_delta_F3_ode,'bo','LineWidth',2,'MarkerSize',10);
box on;
set(gca, 'FontName', 'Cambria Math'); % 设置字体
set(gca, 'FontSize', 18); % 设置字体大小
set(gca, 'LineWidth', 1); % 设置边框大小
title('(d) type-3','FontSize',18);
axis([3 6 0.1 0.4]);
xlabel('\langlek_{\Delta}\rangle'), ylabel('\lambda^c_{\Delta}')
% legend('HMF','Numerical simulation','Location','northeast','FontSize',10,'Box','off');

ax5=subplot(2, 4, 5);
hold on;
fill([3:0.25:6, fliplr(3:0.25:6)], [lambda_delta_F0_SF+lambda_delta_F0_SF_std, fliplr(lambda_delta_F0_SF-lambda_delta_F0_SF_std)],[0.8, 0.8, 0.9], 'EdgeColor', 'none');
plot(3:0.25:6,lambda_delta_F0_SF,'r-',3:0.5:6,lambda_delta_F0_SF_ode,'bo','LineWidth',2,'MarkerSize',10);
box on;
set(gca, 'FontName', 'Cambria Math'); % 设置字体
set(gca, 'FontSize', 18); % 设置字体大小
set(gca, 'LineWidth', 1); % 设置边框大小
title('(e) type-0','FontSize',18);
axis([3 6 0.2 0.8]);
xlabel('\langlek_{\Delta}\rangle'), ylabel('\lambda^c_{\Delta}')
% legend('HMF','Numerical simulation','Location','southwest','FontSize',10,'Box','off');

ax6=subplot(2, 4, 6);
hold on;
fill([3:0.25:6, fliplr(3:0.25:6)], [lambda_delta_F1_SF+lambda_delta_F1_SF_std, fliplr(lambda_delta_F1_SF-lambda_delta_F1_SF_std)],[0.8, 0.8, 0.9], 'EdgeColor', 'none');
plot(3:0.25:6,lambda_delta_F1_SF,'r-',3:0.5:6,lambda_delta_F1_SF_ode,'bo','LineWidth',2,'MarkerSize',10);
box on;
set(gca, 'FontName', 'Cambria Math'); % 设置字体
set(gca, 'FontSize', 18); % 设置字体大小
set(gca, 'LineWidth', 1); % 设置边框大小
title('(f) type-1','FontSize',18);
axis([3 6 0.2 0.8]);
xlabel('\langlek_{\Delta}\rangle'), ylabel('\lambda^c_{\Delta}')
% legend('HMF','Numerical simulation','Location','southwest','FontSize',10,'Box','off');

ax7=subplot(2, 4, 7);
hold on;
fill([3:0.25:6, fliplr(3:0.25:6)], [lambda_delta_F2_SF+lambda_delta_F2_SF_std, fliplr(lambda_delta_F2_SF-lambda_delta_F2_SF_std)],[0.8, 0.8, 0.9], 'EdgeColor', 'none');
plot(3:0.25:6,lambda_delta_F2_SF,'r-',3:0.5:6,lambda_delta_F2_SF_ode,'bo','LineWidth',2,'MarkerSize',10);
box on;
set(gca, 'FontName', 'Cambria Math'); % 设置字体
set(gca, 'FontSize', 18); % 设置字体大小
set(gca, 'LineWidth', 1); % 设置边框大小
title('(g) type-2','FontSize',18);
axis([3 6 0.2 0.8]);
xlabel('\langlek_{\Delta}\rangle'), ylabel('\lambda^c_{\Delta}')
% legend('HMF','Numerical simulation','Location','northeast','FontSize',10,'Box','off');

ax8=subplot(2, 4, 8);
hold on;
fill([3:0.25:6, fliplr(3:0.25:6)], [lambda_delta_F3_SF+lambda_delta_F3_SF_std, fliplr(lambda_delta_F3_SF-lambda_delta_F3_SF_std)],[0.8, 0.8, 0.9], 'EdgeColor', 'none');
plot(3:0.25:6,lambda_delta_F3_SF,'r-',3:0.5:6,lambda_delta_F3_SF_ode,'bo','LineWidth',2,'MarkerSize',10);
box on;
set(gca, 'FontName', 'Cambria Math'); % 设置字体
set(gca, 'FontSize', 18); % 设置字体大小
set(gca, 'LineWidth', 1); % 设置边框大小
title('(h) type-3','FontSize',18);
axis([3 6 0.2 0.8]);
xlabel('\langlek_{\Delta}\rangle'), ylabel('\lambda^c_{\Delta}')
% legend('HMF','Numerical simulation','Location','northeast','FontSize',10,'Box','off');

%调整子图位置
pos1 = ax1.Position; 
ax1.Position = [pos1(1)-0.01, pos1(2)+0.05, pos1(3), pos1(4)]; 
pos2 = ax2.Position; 
ax2.Position = [pos2(1)-0.01, pos2(2)+0.05, pos2(3), pos2(4)]; 
pos3 = ax3.Position; 
ax3.Position = [pos3(1)-0.01, pos3(2)+0.05, pos3(3), pos3(4)]; 
pos4 = ax4.Position; 
ax4.Position = [pos4(1)-0.01, pos4(2)+0.05, pos4(3), pos4(4)]; 
pos5 = ax5.Position; 
ax5.Position = [pos5(1)-0.01, pos5(2)+0.02, pos5(3), pos5(4)]; 
pos6 = ax6.Position; 
ax6.Position = [pos6(1)-0.01, pos6(2)+0.02, pos6(3), pos6(4)]; 
pos7 = ax7.Position; 
ax7.Position = [pos7(1)-0.01, pos7(2)+0.02, pos7(3), pos7(4)]; 
pos8 = ax8.Position; 
ax8.Position = [pos8(1)-0.01, pos8(2)+0.02, pos8(3), pos8(4)]; 

fig = gcf;
figPos = fig.Position;  % [左, 下, 宽, 高]

leg = legend([h1, h2]); 
set(leg, 'Units', 'normalized', 'Position', [0.93, 0.5, 0.01, 0.02]);

allAxes = findobj(fig, 'Type', 'axes', '-not', 'Tag', 'legend');
% 调整每个坐标轴宽度（缩小15%给图注腾空间）
for i = 1:length(allAxes)
    axPos = get(allAxes(i), 'Position');
    set(allAxes(i), 'Position', [axPos(1), axPos(2), axPos(3)*0.85, axPos(4)*0.9]);
end