clear all;
close all;
clc;

%每个网络出现双稳态的λΔ与<kΔ>的关系
%<kΔ>从3到6

lambda_delta_F3=[0.302,0.267,0.229,0.205,0.183,0.169,0.158];
lambda_delta_F2=[0.330,0.284,0.248,0.218,0.196,0.177,0.164];
lambda_delta_F1=[0.359,0.310,0.270,0.236,0.213,0.193,0.179];
lambda_delta_F0=[0.394,0.336,0.299,0.264,0.232,0.217,0.199];

lambda_delta_F3_SF=[0.575,0.491,0.435,0.383,0.330,0.299,0.261];
lambda_delta_F2_SF=[0.623,0.544,0.473,0.421,0.381,0.341,0.310];
lambda_delta_F1_SF=[0.646,0.578,0.505,0.455,0.404,0.375,0.347];
lambda_delta_F0_SF=[0.673,0.599,0.530,0.478,0.437,0.400,0.368];


figure('Position', [100, 100, 1500, 600]);

subplot(1, 2, 1);
hold on;
plot(3:0.5:6,lambda_delta_F0,'ko--','LineWidth',2,'MarkerSize',10);
plot(3:0.5:6,lambda_delta_F1,'go--','LineWidth',2,'MarkerSize',10);
plot(3:0.5:6,lambda_delta_F2,'bo--','LineWidth',2,'MarkerSize',10);
plot(3:0.5:6,lambda_delta_F3,'ro--','LineWidth',2,'MarkerSize',10);

box on;
axis([3 6 0.1 0.4]);
set(gca, 'FontName', 'Cambria Math'); % 设置字体
set(gca, 'FontSize', 24); % 设置字体大小
set(gca, 'LineWidth', 2); % 设置边框大小
title('(a) ER-based network');
xlabel('<k_{\Delta}>'), ylabel('\lambda^c_{\Delta}')
xticks([3 3.5 4 4.5 5 5.5 6]); % 设置 x 轴刻度位置
yticks([0.1 0.2 0.3 0.4]); % 设置 y 轴刻度位置
legend('Type-0 network','Type-1 network','Type-2 network','Type-3 network','Location','northeast','Box','off','FontSize',16);

subplot(1, 2, 2);
hold on;
plot(3:0.5:6,lambda_delta_F0_SF,'ko--','LineWidth',2,'MarkerSize',10);
plot(3:0.5:6,lambda_delta_F1_SF,'go--','LineWidth',2,'MarkerSize',10);
plot(3:0.5:6,lambda_delta_F2_SF,'bo--','LineWidth',2,'MarkerSize',10);
plot(3:0.5:6,lambda_delta_F3_SF,'ro--','LineWidth',2,'MarkerSize',10);

box on;
axis([3 6 0.2 0.8]);
set(gca, 'FontName', 'Cambria Math'); % 设置字体
set(gca, 'FontSize', 24); % 设置字体大小
set(gca, 'LineWidth', 2); % 设置边框大小
title('(b) SF-based network');
xlabel('<k_{\Delta}>'), ylabel('\lambda^c_{\Delta}')
xticks([3 3.5 4 4.5 5 5.5 6]); % 设置 x 轴刻度位置
yticks([0.2 0.4 0.6 0.8]); % 设置 y 轴刻度位置
legend('Type-0 network','Type-1 network','Type-2 network','Type-3 network','Location','northeast','Box','off','FontSize',16);