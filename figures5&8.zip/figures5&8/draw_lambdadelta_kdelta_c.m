clear all;
close all;
clc;

%每个网络出现双稳态的λΔ与<kΔ>的关系
%<kΔ>从3到6

lambda_delta_F3=[0.3224,0.2773,0.2424,0.2149,0.1924,0.1759,0.1610];
lambda_delta_F2=[0.3309,0.2836,0.2474,0.2189,0.1958,0.1790,0.1631];
lambda_delta_F1=[0.3410,0.2920,0.2566,0.2250,0.2008,0.1834,0.1698];
lambda_delta_F0=[0.3509,0.2979,0.2643,0.2331,0.2068,0.1894,0.1734];

% lambda_delta_F3_SF=[0.6296,0.4910,0.4441,0.3680,0.2932,0.2745,0.2407];
% lambda_delta_F2_SF=[0.7586,0.6773,0.4980,0.4417,0.3905,0.3423,0.2982];
% lambda_delta_F1_SF=[0.7074,0.6450,0.5948,0.4871,0.4101,0.3726,0.4076];
% lambda_delta_F0_SF=[0.7773,0.6772,0.5871,0.5601,0.4495,0.4511,0.4153];

lambda_delta_F3_SF=[0.63420,0.53024,0.45806,0.38260,0.32880,0.27588,0.24466];
lambda_delta_F2_SF=[0.73300,0.59214,0.49210,0.45172,0.39048,0.34908,0.29310];
lambda_delta_F1_SF=[0.74920,0.64096,0.56508,0.47572,0.44638,0.39250,0.37044];
lambda_delta_F0_SF=[0.77862,0.67668,0.59252,0.54010,0.46716,0.43220,0.39636];

figure('Position', [100, 100, 1500, 600]);

subplot(1, 2, 1);
hold on;
plot(3:0.5:6,lambda_delta_F0,'ko--','LineWidth',2,'MarkerSize',10);
plot(3:0.5:6,lambda_delta_F1,'go--','LineWidth',2,'MarkerSize',10);
plot(3:0.5:6,lambda_delta_F2,'bo--','LineWidth',2,'MarkerSize',10);
plot(3:0.5:6,lambda_delta_F3,'ro--','LineWidth',2,'MarkerSize',10);

box on;
axis([3 6 0.1 0.4]);
set(gca, 'FontName', 'Cambria Math'); % 设置字体
set(gca, 'FontSize', 18); % 设置字体大小
set(gca, 'LineWidth', 2); % 设置边框大小
title('(a) ER-based network','FontSize',18);
xlabel('<k_{\Delta}>'), ylabel('\lambda^c_{\Delta}')
xticks([3 3.5 4 4.5 5 5.5 6]); % 设置 x 轴刻度位置
yticks([0.1 0.2 0.3 0.4]); % 设置 y 轴刻度位置
legend('Type-0 network','Type-1 network','Type-2 network','Type-3 network','Location','northeast','Box','off','FontSize',14);

subplot(1, 2, 2);
hold on;
plot(3:0.5:6,lambda_delta_F0_SF,'ko--','LineWidth',2,'MarkerSize',10);
plot(3:0.5:6,lambda_delta_F1_SF,'go--','LineWidth',2,'MarkerSize',10);
plot(3:0.5:6,lambda_delta_F2_SF,'bo--','LineWidth',2,'MarkerSize',10);
plot(3:0.5:6,lambda_delta_F3_SF,'ro--','LineWidth',2,'MarkerSize',10);

box on;
axis([3 6 0.1 0.8]);
set(gca, 'FontName', 'Cambria Math'); % 设置字体
set(gca, 'FontSize', 18); % 设置字体大小
set(gca, 'LineWidth', 2); % 设置边框大小
title('(b) SF-based network','FontSize',18);
xlabel('<k_{\Delta}>'), ylabel('\lambda^c_{\Delta}')
xticks([3 3.5 4 4.5 5 5.5 6]); % 设置 x 轴刻度位置
yticks([0.2 0.4 0.6 0.8]); % 设置 y 轴刻度位置
legend('Type-0 network','Type-1 network','Type-2 network','Type-3 network','Location','northeast','Box','off','FontSize',14);