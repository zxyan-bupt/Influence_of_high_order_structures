clear all;
close all;
clc;

lambda_delta_3_ode=[0.394,0.359,0.330,0.302];
lambda_delta_4_ode=[0.299,0.270,0.248,0.229];
lambda_delta_5_ode=[0.232,0.213,0.196,0.183,];
lambda_delta_6_ode=[0.199,0.179,0.164,0.158];

lambda_delta_3_SF_ode=[0.673,0.646,0.623,0.575];
lambda_delta_4_SF_ode=[0.530,0.505,0.473,0.435];
lambda_delta_5_SF_ode=[0.437,0.404,0.381,0.330];
lambda_delta_6_SF_ode=[0.368,0.347,0.310,0.261];

lambda_delta_3=[0.3509,0.3410,0.3309,0.3224];
lambda_delta_4=[0.2643,0.2566,0.2474,0.2424];
lambda_delta_5=[0.2068,0.2008,0.1958,0.1924];
lambda_delta_6=[0.1734,0.1698,0.1631,0.1610];

lambda_delta_3_SF=[0.77862,0.74920,0.73300,0.63420];
lambda_delta_4_SF=[0.59252,0.56508,0.49210,0.45806];
lambda_delta_5_SF=[0.46716,0.44638,0.39048,0.32880];
lambda_delta_6_SF=[0.39636,0.37044,0.29310,0.24466];


figure('Position', [100, 100, 1500, 600]);

subplot(2, 4, 1);
plot(0:1:3,lambda_delta_3,'bo',0:1:3,lambda_delta_3_ode,'r','LineWidth',2,'MarkerSize',10);
box on;
set(gca, 'FontName', 'Cambria Math'); % 设置字体
set(gca, 'FontSize', 14); % 设置字体大小
set(gca, 'LineWidth', 1); % 设置边框大小
title('(a) ER-based(\langlek_{\Delta}\rangle=3)','FontSize',16);
axis([0 3 0.1 0.4]);
xlabel('the type of network'), ylabel('\lambda^c_{\Delta}')
legend('HMF','Numerical simulation','Location','southwest','FontSize',12,'Box','off');

subplot(2, 4, 2);
plot(0:1:3,lambda_delta_4,'bo',0:1:3,lambda_delta_4_ode,'r','LineWidth',2,'MarkerSize',10);
box on;
set(gca, 'FontName', 'Cambria Math'); % 设置字体
set(gca, 'FontSize', 14); % 设置字体大小
set(gca, 'LineWidth', 1); % 设置边框大小
title('(b) ER-based(\langlek_{\Delta}\rangle=4)','FontSize',16);
axis([0 3 0.1 0.4]);
xlabel('the type of network'), ylabel('\lambda^c_{\Delta}')
legend('HMF','Numerical simulation','Location','southwest','FontSize',12,'Box','off');

subplot(2, 4, 3);
plot(0:1:3,lambda_delta_5,'bo',0:1:3,lambda_delta_5_ode,'r','LineWidth',2,'MarkerSize',10);
box on;
set(gca, 'FontName', 'Cambria Math'); % 设置字体
set(gca, 'FontSize', 14); % 设置字体大小
set(gca, 'LineWidth', 1); % 设置边框大小
title('(c) ER-based(\langlek_{\Delta}\rangle=5)','FontSize',16);
axis([0 3 0.1 0.4]);
xlabel('the type of network'), ylabel('\lambda^c_{\Delta}')
legend('HMF','Numerical simulation','Location','northeast','FontSize',12,'Box','off');

subplot(2, 4, 4);
plot(0:1:3,lambda_delta_6,'bo',0:1:3,lambda_delta_6_ode,'r','LineWidth',2,'MarkerSize',10);
box on;
set(gca, 'FontName', 'Cambria Math'); % 设置字体
set(gca, 'FontSize', 14); % 设置字体大小
set(gca, 'LineWidth', 1); % 设置边框大小
title('(d) ER-based(\langlek_{\Delta}\rangle=6)','FontSize',16);
axis([0 3 0.1 0.4]);
xlabel('the type of network'), ylabel('\lambda^c_{\Delta}')
legend('HMF','Numerical simulation','Location','northeast','FontSize',12,'Box','off');

subplot(2, 4, 5);
plot(0:1:3,lambda_delta_3_SF,'bo',0:1:3,lambda_delta_3_SF_ode,'r','LineWidth',2,'MarkerSize',10);
box on;
set(gca, 'FontName', 'Cambria Math'); % 设置字体
set(gca, 'FontSize', 14); % 设置字体大小
set(gca, 'LineWidth', 1); % 设置边框大小
title('(e) SF-based(\langlek_{\Delta}\rangle=3)','FontSize',16);
axis([0 3 0.2 0.8]);
xlabel('the type of network'), ylabel('\lambda^c_{\Delta}')
legend('HMF','Numerical simulation','Location','southwest','FontSize',12,'Box','off');

subplot(2, 4, 6);
plot(0:1:3,lambda_delta_4_SF,'bo',0:1:3,lambda_delta_4_SF_ode,'r','LineWidth',2,'MarkerSize',10);
box on;
set(gca, 'FontName', 'Cambria Math'); % 设置字体
set(gca, 'FontSize', 14); % 设置字体大小
set(gca, 'LineWidth', 1); % 设置边框大小
title('(f) SF-based(\langlek_{\Delta}\rangle=4)','FontSize',16);
axis([0 3 0.2 0.8]);
xlabel('the type of network'), ylabel('\lambda^c_{\Delta}')
legend('HMF','Numerical simulation','Location','southwest','FontSize',12,'Box','off');

subplot(2, 4, 7);
plot(0:1:3,lambda_delta_5_SF,'bo',0:1:3,lambda_delta_5_SF_ode,'r','LineWidth',2,'MarkerSize',10);
box on;
set(gca, 'FontName', 'Cambria Math'); % 设置字体
set(gca, 'FontSize', 14); % 设置字体大小
set(gca, 'LineWidth', 1); % 设置边框大小
title('(g) SF-based(\langlek_{\Delta}\rangle=5)','FontSize',16);
axis([0 3 0.2 0.8]);
xlabel('the type of network'), ylabel('\lambda^c_{\Delta}')
legend('HMF','Numerical simulation','Location','northeast','FontSize',12,'Box','off');

subplot(2, 4, 8);
plot(0:1:3,lambda_delta_6_SF,'bo',0:1:3,lambda_delta_6_SF_ode,'r','LineWidth',2,'MarkerSize',10);
box on;
set(gca, 'FontName', 'Cambria Math'); % 设置字体
set(gca, 'FontSize', 14); % 设置字体大小
set(gca, 'LineWidth', 1); % 设置边框大小
title('(h) SF-based(\langlek_{\Delta}\rangle=6)','FontSize',16);
axis([0 3 0.2 0.8]);
xlabel('the type of network'), ylabel('\lambda^c_{\Delta}')
legend('HMF','Numerical simulation','Location','northeast','FontSize',12,'Box','off');