clear all;
close all;
clc;

lambda_delta_F3_ode=[0.302,0.267,0.229,0.205,0.183,0.169,0.158];
lambda_delta_F2_ode=[0.330,0.284,0.248,0.218,0.196,0.177,0.164];
lambda_delta_F1_ode=[0.359,0.310,0.270,0.236,0.213,0.193,0.179];
lambda_delta_F0_ode=[0.394,0.336,0.299,0.264,0.232,0.217,0.199];

lambda_delta_F3_SF_ode=[0.575,0.491,0.435,0.383,0.330,0.299,0.261];
lambda_delta_F2_SF_ode=[0.623,0.544,0.473,0.421,0.381,0.341,0.310];
lambda_delta_F1_SF_ode=[0.646,0.578,0.505,0.455,0.404,0.375,0.347];
lambda_delta_F0_SF_ode=[0.673,0.599,0.530,0.478,0.437,0.400,0.368];

lambda_delta_F3=[0.3224,0.2773,0.2424,0.2149,0.1924,0.1759,0.1610];
lambda_delta_F2=[0.3309,0.2836,0.2474,0.2189,0.1958,0.1790,0.1631];
lambda_delta_F1=[0.3410,0.2920,0.2566,0.2250,0.2008,0.1834,0.1698];
lambda_delta_F0=[0.3509,0.2979,0.2643,0.2331,0.2068,0.1894,0.1734];

lambda_delta_F3_SF=[0.63420,0.53024,0.45806,0.38260,0.32880,0.27588,0.24466];
lambda_delta_F2_SF=[0.73300,0.59214,0.49210,0.45172,0.39048,0.34908,0.29310];
lambda_delta_F1_SF=[0.74920,0.64096,0.56508,0.47572,0.44638,0.39250,0.37044];
lambda_delta_F0_SF=[0.77862,0.67668,0.59252,0.54010,0.46716,0.43220,0.39636];

figure('Position', [100, 100, 1600, 600]);

ax1=subplot(2, 4, 1);
hold on;
h1=plot(3:0.5:6,lambda_delta_F0,'r-','LineWidth',2,'MarkerSize',10,'DisplayName', 'HMF');
h2=plot(3:0.5:6,lambda_delta_F0_ode,'bo','LineWidth',2,'MarkerSize',10,'DisplayName', 'Numerical\newlinesimulation');
box on;
set(gca, 'FontName', 'Cambria Math'); % 设置字体
set(gca, 'FontSize', 18); % 设置字体大小
set(gca, 'LineWidth', 1); % 设置边框大小
title('(a) type-0','FontSize',18);
axis([3 6 0.1 0.4]);
xlabel('\langlek_{\Delta}\rangle'), ylabel('\lambda^c_{\Delta}')
% legend('HMF','Numerical simulation','Location','southwest','FontSize',10,'Box','off');

ax2=subplot(2, 4, 2);
plot(3:0.5:6,lambda_delta_F1,'r-',3:0.5:6,lambda_delta_F1_ode,'bo','LineWidth',2,'MarkerSize',10);
box on;
set(gca, 'FontName', 'Cambria Math'); % 设置字体
set(gca, 'FontSize', 18); % 设置字体大小
set(gca, 'LineWidth', 1); % 设置边框大小
title('(b) type-1','FontSize',18);
axis([3 6 0.1 0.4]);
xlabel('\langlek_{\Delta}\rangle'), ylabel('\lambda^c_{\Delta}')
% legend('HMF','Numerical simulation','Location','southwest','FontSize',10,'Box','off');

ax3=subplot(2, 4, 3);
plot(3:0.5:6,lambda_delta_F2,'r-',3:0.5:6,lambda_delta_F2_ode,'bo','LineWidth',2,'MarkerSize',10);
box on;
set(gca, 'FontName', 'Cambria Math'); % 设置字体
set(gca, 'FontSize', 18); % 设置字体大小
set(gca, 'LineWidth', 1); % 设置边框大小
title('(c) type-2','FontSize',18);
axis([3 6 0.1 0.4]);
xlabel('\langlek_{\Delta}\rangle'), ylabel('\lambda^c_{\Delta}')
% legend('HMF','Numerical simulation','Location','northeast','FontSize',10,'Box','off');

ax4=subplot(2, 4, 4);
plot(3:0.5:6,lambda_delta_F3,'r-',3:0.5:6,lambda_delta_F3_ode,'bo','LineWidth',2,'MarkerSize',10);
box on;
set(gca, 'FontName', 'Cambria Math'); % 设置字体
set(gca, 'FontSize', 18); % 设置字体大小
set(gca, 'LineWidth', 1); % 设置边框大小
title('(d) type-3','FontSize',18);
axis([3 6 0.1 0.4]);
xlabel('\langlek_{\Delta}\rangle'), ylabel('\lambda^c_{\Delta}')
% legend('HMF','Numerical simulation','Location','northeast','FontSize',10,'Box','off');

ax5=subplot(2, 4, 5);
plot(3:0.5:6,lambda_delta_F0_SF,'r-',3:0.5:6,lambda_delta_F0_SF_ode,'bo','LineWidth',2,'MarkerSize',10);
box on;
set(gca, 'FontName', 'Cambria Math'); % 设置字体
set(gca, 'FontSize', 18); % 设置字体大小
set(gca, 'LineWidth', 1); % 设置边框大小
title('(e) type-0','FontSize',18);
axis([3 6 0.2 0.8]);
xlabel('\langlek_{\Delta}\rangle'), ylabel('\lambda^c_{\Delta}')
% legend('HMF','Numerical simulation','Location','southwest','FontSize',10,'Box','off');

ax6=subplot(2, 4, 6);
plot(3:0.5:6,lambda_delta_F1_SF,'r-',3:0.5:6,lambda_delta_F1_SF_ode,'bo','LineWidth',2,'MarkerSize',10);
box on;
set(gca, 'FontName', 'Cambria Math'); % 设置字体
set(gca, 'FontSize', 18); % 设置字体大小
set(gca, 'LineWidth', 1); % 设置边框大小
title('(f) type-1','FontSize',18);
axis([3 6 0.2 0.8]);
xlabel('\langlek_{\Delta}\rangle'), ylabel('\lambda^c_{\Delta}')
% legend('HMF','Numerical simulation','Location','southwest','FontSize',10,'Box','off');

ax7=subplot(2, 4, 7);
plot(3:0.5:6,lambda_delta_F2_SF,'r-',3:0.5:6,lambda_delta_F2_SF_ode,'bo','LineWidth',2,'MarkerSize',10);
box on;
set(gca, 'FontName', 'Cambria Math'); % 设置字体
set(gca, 'FontSize', 18); % 设置字体大小
set(gca, 'LineWidth', 1); % 设置边框大小
title('(g) type-2','FontSize',18);
axis([3 6 0.2 0.8]);
xlabel('\langlek_{\Delta}\rangle'), ylabel('\lambda^c_{\Delta}')
% legend('HMF','Numerical simulation','Location','northeast','FontSize',10,'Box','off');

ax8=subplot(2, 4, 8);
plot(3:0.5:6,lambda_delta_F3_SF,'r-',3:0.5:6,lambda_delta_F3_SF_ode,'bo','LineWidth',2,'MarkerSize',10);
box on;
set(gca, 'FontName', 'Cambria Math'); % 设置字体
set(gca, 'FontSize', 18); % 设置字体大小
set(gca, 'LineWidth', 1); % 设置边框大小
title('(h) type-3','FontSize',18);
axis([3 6 0.2 0.8]);
xlabel('\langlek_{\Delta}\rangle'), ylabel('\lambda^c_{\Delta}')
% legend('HMF','Numerical simulation','Location','northeast','FontSize',10,'Box','off');

%调整子图位置
pos1 = ax1.Position; 
ax1.Position = [pos1(1)-0.01, pos1(2)+0.05, pos1(3), pos1(4)]; 
pos2 = ax2.Position; 
ax2.Position = [pos2(1)-0.01, pos2(2)+0.05, pos2(3), pos2(4)]; 
pos3 = ax3.Position; 
ax3.Position = [pos3(1)-0.01, pos3(2)+0.05, pos3(3), pos3(4)]; 
pos4 = ax4.Position; 
ax4.Position = [pos4(1)-0.01, pos4(2)+0.05, pos4(3), pos4(4)]; 
pos5 = ax5.Position; 
ax5.Position = [pos5(1)-0.01, pos5(2)+0.02, pos5(3), pos5(4)]; 
pos6 = ax6.Position; 
ax6.Position = [pos6(1)-0.01, pos6(2)+0.02, pos6(3), pos6(4)]; 
pos7 = ax7.Position; 
ax7.Position = [pos7(1)-0.01, pos7(2)+0.02, pos7(3), pos7(4)]; 
pos8 = ax8.Position; 
ax8.Position = [pos8(1)-0.01, pos8(2)+0.02, pos8(3), pos8(4)]; 

fig = gcf;
figPos = fig.Position;  % [左, 下, 宽, 高]

leg = legend([h1, h2]); 
set(leg, 'Units', 'normalized', 'Position', [0.93, 0.5, 0.01, 0.02]);

allAxes = findobj(fig, 'Type', 'axes', '-not', 'Tag', 'legend');
% 调整每个坐标轴宽度（缩小15%给图注腾空间）
for i = 1:length(allAxes)
    axPos = get(allAxes(i), 'Position');
    set(allAxes(i), 'Position', [axPos(1), axPos(2), axPos(3)*0.85, axPos(4)*0.9]);
end