clear all;
close all;
clc;

% lambda_delta=0.385 01之间
% type 0 ER-based
ER_rho_plot_h_01_0ccl=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.385_h_ccl.txt','\t');
ER_rho_plot_h_01_0cl=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.385_h_cl.txt','\t');
ER_rho_plot_h_01_0=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.385_h_x.txt','\t');
ER_rho_plot_l_01_0=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.385_l_x.txt','\t');
ER_rho_plot_h_01_0cr=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.385_h_cr.txt','\t');
ER_rho_plot_h_01_0ccr=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.385_h_ccr.txt','\t');
ER_lambda1_plot_01_0ccl=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.385_lambda1_plot_ccl.txt','\t');
ER_lambda1_plot_01_0cl=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.385_lambda1_plot_cl.txt','\t');
ER_lambda1_plot_01_0=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.385_lambda1_plot_x.txt','\t');
ER_lambda1_plot_01_0cr=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.385_lambda1_plot_cr.txt','\t');
ER_lambda1_plot_01_0ccr=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.385_lambda1_plot_ccr.txt','\t');
% type 1 ER-based
ER_rho_plot_h_01_1ccl=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.385_h_ccl.txt','\t');
ER_rho_plot_h_01_1cl=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.385_h_cl.txt','\t');
ER_rho_plot_h_01_1=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.385_h_x.txt','\t');
ER_rho_plot_l_01_1=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.385_l_x.txt','\t');
ER_rho_plot_h_01_1cr=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.385_h_cr.txt','\t');
ER_rho_plot_h_01_1ccr=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.385_h_ccr.txt','\t');
ER_lambda1_plot_01_1ccl=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.385_lambda1_plot_ccl.txt','\t');
ER_lambda1_plot_01_1cl=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.385_lambda1_plot_cl.txt','\t');
ER_lambda1_plot_01_1=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.385_lambda1_plot_x.txt','\t');
ER_lambda1_plot_01_1cr=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.385_lambda1_plot_cr.txt','\t');
ER_lambda1_plot_01_1ccr=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.385_lambda1_plot_ccr.txt','\t');
% type 2 ER-based
ER_rho_plot_h_01_2ccl=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.385_h_ccl.txt','\t');
ER_rho_plot_h_01_2c=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.385_h_c.txt','\t');
ER_rho_plot_l_01_2c=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.385_l_c.txt','\t');
ER_rho_plot_h_01_2ccr=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.385_h_ccr.txt','\t');
ER_lambda1_plot_01_2ccl=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.385_lambda1_plot_ccl.txt','\t');
ER_lambda1_plot_01_2c=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.385_lambda1_plot_c.txt','\t');
ER_lambda1_plot_01_2ccr=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.385_lambda1_plot_ccr.txt','\t');
% type 3 ER-based
ER_rho_plot_h_01_3ccl=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.385_h_ccl.txt','\t');
ER_rho_plot_h_01_3c=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.385_h_c.txt','\t');
ER_rho_plot_l_01_3c=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.385_l_c.txt','\t');
ER_rho_plot_h_01_3ccr=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.385_h_ccr.txt','\t');
ER_lambda1_plot_01_3ccl=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.385_lambda1_plot_ccl.txt','\t');
ER_lambda1_plot_01_3c=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.385_lambda1_plot_c.txt','\t');
ER_lambda1_plot_01_3ccr=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.385_lambda1_plot_ccr.txt','\t');

% lambda_delta=0.35 12之间
% type 0 ER-based
ER_rho_plot_h_12_0ccl=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.35_h_ccl.txt','\t');
ER_rho_plot_h_12_0c=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.35_h_c.txt','\t');
ER_rho_plot_l_12_0c=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.35_l_c.txt','\t');
ER_rho_plot_h_12_0ccr=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.35_h_ccr.txt','\t');
ER_lambda1_plot_12_0ccl=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.35_lambda1_plot_ccl.txt','\t');
ER_lambda1_plot_12_0c=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.35_lambda1_plot_c.txt','\t');
ER_lambda1_plot_12_0ccr=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.35_lambda1_plot_ccr.txt','\t');
% type 1 ER-based
ER_rho_plot_h_12_1ccl=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.35_h_ccl.txt','\t');
ER_rho_plot_h_12_1cl=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.35_h_cl.txt','\t');
ER_rho_plot_h_12_1=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.35_h_x.txt','\t');
ER_rho_plot_l_12_1=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.35_l_x.txt','\t');
ER_rho_plot_h_12_1cr=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.35_h_cr.txt','\t');
ER_rho_plot_h_12_1ccr=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.35_h_ccr.txt','\t');
ER_rho_plot_l_12_1=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.35_l_x.txt','\t');
ER_lambda1_plot_12_1ccl=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.35_lambda1_plot_ccl.txt','\t');
ER_lambda1_plot_12_1cl=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.35_lambda1_plot_cl.txt','\t');
ER_lambda1_plot_12_1=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.35_lambda1_plot_x.txt','\t');
ER_lambda1_plot_12_1cr=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.35_lambda1_plot_cr.txt','\t');
ER_lambda1_plot_12_1ccr=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.35_lambda1_plot_ccr.txt','\t');
% type 2 ER-based
ER_rho_plot_h_12_2ccl=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.35_h_ccl.txt','\t');
ER_rho_plot_h_12_2cl=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.35_h_cl.txt','\t');
ER_rho_plot_h_12_2=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.35_h_x.txt','\t');
ER_rho_plot_l_12_2=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.35_l_x.txt','\t');
ER_rho_plot_h_12_2cr=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.35_h_cr.txt','\t');
ER_rho_plot_h_12_2ccr=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.35_h_ccr.txt','\t');
ER_lambda1_plot_12_2ccl=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.35_lambda1_plot_ccl.txt','\t');
ER_lambda1_plot_12_2cl=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.35_lambda1_plot_cl.txt','\t');
ER_lambda1_plot_12_2=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.35_lambda1_plot_x.txt','\t');
ER_lambda1_plot_12_2cr=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.35_lambda1_plot_cr.txt','\t');
ER_lambda1_plot_12_2ccr=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.35_lambda1_plot_ccr.txt','\t');
% type 3 ER-based
ER_rho_plot_h_12_3ccl=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.35_h_ccl.txt','\t');
ER_rho_plot_h_12_3c=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.35_h_c.txt','\t');
ER_rho_plot_l_12_3c=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.35_l_c.txt','\t');
ER_rho_plot_h_12_3ccr=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.35_h_ccr.txt','\t');
ER_lambda1_plot_12_3ccl=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.35_lambda1_plot_ccl.txt','\t');
ER_lambda1_plot_12_3c=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.35_lambda1_plot_c.txt','\t');
ER_lambda1_plot_12_3ccr=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.35_lambda1_plot_ccr.txt','\t');

% lambda_delta=0.32 23之间
% type 0 ER-based
ER_rho_plot_h_23_0ccl=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.32_h_ccl.txt','\t');
ER_rho_plot_h_23_0c=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.32_h_c.txt','\t');
ER_rho_plot_l_23_0c=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.32_l_c.txt','\t');
ER_rho_plot_h_23_0ccr=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.32_h_ccr.txt','\t');
ER_lambda1_plot_23_0ccl=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.32_lambda1_plot_ccl.txt','\t');
ER_lambda1_plot_23_0c=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.32_lambda1_plot_c.txt','\t');
ER_lambda1_plot_23_0ccr=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.32_lambda1_plot_ccr.txt','\t');
% type 1 ER-based
ER_rho_plot_h_23_1ccl=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.32_h_ccl.txt','\t');
ER_rho_plot_h_23_1c=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.32_h_c.txt','\t');
ER_rho_plot_l_23_1c=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.32_l_c.txt','\t');
ER_rho_plot_h_23_1ccr=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.32_h_ccr.txt','\t');
ER_lambda1_plot_23_1ccl=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.32_lambda1_plot_ccl.txt','\t');
ER_lambda1_plot_23_1c=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.32_lambda1_plot_c.txt','\t');
ER_lambda1_plot_23_1ccr=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.32_lambda1_plot_ccr.txt','\t');
% type 2 ER-based
ER_rho_plot_h_23_2ccl=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.32_h_ccl.txt','\t');
ER_rho_plot_h_23_2cl=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.32_h_cl.txt','\t');
ER_rho_plot_h_23_2=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.32_h_x.txt','\t');
ER_rho_plot_l_23_2=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.32_l_x.txt','\t');
ER_rho_plot_h_23_2cr=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.32_h_cr.txt','\t');
ER_rho_plot_h_23_2ccr=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.32_h_ccr.txt','\t');
ER_lambda1_plot_23_2ccl=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.32_lambda1_plot_ccl.txt','\t');
ER_lambda1_plot_23_2cl=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.32_lambda1_plot_cl.txt','\t');
ER_lambda1_plot_23_2=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.32_lambda1_plot_x.txt','\t');
ER_lambda1_plot_23_2cr=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.32_lambda1_plot_cr.txt','\t');
ER_lambda1_plot_23_2ccr=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.32_lambda1_plot_ccr.txt','\t');
% type 3 ER-based
ER_rho_plot_h_23_3ccl=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.32_h_ccl.txt','\t');
ER_rho_plot_h_23_3cl=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.32_h_cl.txt','\t');
ER_rho_plot_h_23_3=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.32_h_x.txt','\t');
ER_rho_plot_l_23_3=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.32_l_x.txt','\t');
ER_rho_plot_h_23_3cr=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.32_h_cr.txt','\t');
ER_rho_plot_h_23_3ccr=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.32_h_ccr.txt','\t');
ER_lambda1_plot_23_3ccl=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.32_lambda1_plot_ccl.txt','\t');
ER_lambda1_plot_23_3cl=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.32_lambda1_plot_cl.txt','\t');
ER_lambda1_plot_23_3=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.32_lambda1_plot_x.txt','\t');
ER_lambda1_plot_23_3cr=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.32_lambda1_plot_cr.txt','\t');
ER_lambda1_plot_23_3ccr=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.32_lambda1_plot_ccr.txt','\t');

% lambda_delta=0.665 01之间
% type 0 SF-based
rho_plot_h_01_0cl=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.665_h_cl.txt','\t');
rho_plot_h_01_0=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.665_h_x.txt','\t');
rho_plot_l_01_0=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.665_l_x.txt','\t');
rho_plot_h_01_0cr=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.665_h_cr.txt','\t');
lambda1_plot_01_0cl=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.665_lambda1_plot_cl.txt','\t');
lambda1_plot_01_0=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.665_lambda1_plot_x.txt','\t');
lambda1_plot_01_0cr=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.665_lambda1_plot_cr.txt','\t');
% type 1 SF-based
rho_plot_h_01_1cl=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.665_h_cl.txt','\t');
rho_plot_h_01_1=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.665_h_x.txt','\t');
rho_plot_l_01_1=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.665_l_x.txt','\t');
rho_plot_h_01_1cr=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.665_h_cr.txt','\t');
lambda1_plot_01_1cl=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.665_lambda1_plot_cl.txt','\t');
lambda1_plot_01_1=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.665_lambda1_plot_x.txt','\t');
lambda1_plot_01_1cr=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.665_lambda1_plot_cr.txt','\t');
% type 2 SF-based
rho_plot_h_01_2ccl=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.665_h_ccl.txt','\t');
rho_plot_h_01_2c=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.665_h_c.txt','\t');
rho_plot_l_01_2c=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.665_l_c.txt','\t');
rho_plot_h_01_2ccr=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.665_h_ccr.txt','\t');
lambda1_plot_01_2ccl=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.665_lambda1_plot_ccl.txt','\t');
lambda1_plot_01_2c=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.665_lambda1_plot_c.txt','\t');
lambda1_plot_01_2ccr=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.665_lambda1_plot_ccr.txt','\t');
% type 3 SF-based
rho_plot_h_01_3ccl=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.665_h_ccl.txt','\t');
rho_plot_h_01_3c=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.665_h_c.txt','\t');
rho_plot_l_01_3c=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.665_l_c.txt','\t');
rho_plot_h_01_3ccr=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.665_h_ccr.txt','\t');
lambda1_plot_01_3ccl=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.665_lambda1_plot_ccl.txt','\t');
lambda1_plot_01_3c=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.665_lambda1_plot_c.txt','\t');
lambda1_plot_01_3ccr=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.665_lambda1_plot_ccr.txt','\t');

% lambda_delta=0.640 12之间
% type 0 SF-based
rho_plot_h_12_0ccl=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.640_h_ccl.txt','\t');
rho_plot_h_12_0c=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.640_h_c.txt','\t');
rho_plot_l_12_0c=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.640_l_c.txt','\t');
rho_plot_h_12_0ccr=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.640_h_ccr.txt','\t');
lambda1_plot_12_0ccl=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.640_lambda1_plot_ccl.txt','\t');
lambda1_plot_12_0c=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.640_lambda1_plot_c.txt','\t');
lambda1_plot_12_0ccr=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.640_lambda1_plot_ccr.txt','\t');
% type 1 SF-based
rho_plot_h_12_1cl=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.640_h_cl.txt','\t');
rho_plot_h_12_1=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.640_h_x.txt','\t');
rho_plot_l_12_1=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.640_l_x.txt','\t');
rho_plot_h_12_1cr=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.640_h_cr.txt','\t');
lambda1_plot_12_1cl=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.640_lambda1_plot_cl.txt','\t');
lambda1_plot_12_1=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.640_lambda1_plot_x.txt','\t');
lambda1_plot_12_1cr=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.640_lambda1_plot_cr.txt','\t');
% type 2 SF-based
rho_plot_h_12_2cl=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.640_h_cl.txt','\t');
rho_plot_h_12_2=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.640_h_x.txt','\t');
rho_plot_l_12_2=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.640_l_x.txt','\t');
rho_plot_h_12_2cr=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.640_h_cr.txt','\t');
lambda1_plot_12_2cl=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.640_lambda1_plot_cl.txt','\t');
lambda1_plot_12_2=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.640_lambda1_plot_x.txt','\t');
lambda1_plot_12_2cr=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.640_lambda1_plot_cr.txt','\t');
% type 3 SF-based
rho_plot_h_12_3ccl=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.640_h_ccl.txt','\t');
rho_plot_h_12_3c=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.640_h_c.txt','\t');
rho_plot_l_12_3c=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.640_l_c.txt','\t');
rho_plot_h_12_3ccr=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.640_h_ccr.txt','\t');
lambda1_plot_12_3ccl=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.640_lambda1_plot_ccl.txt','\t');
lambda1_plot_12_3c=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.640_lambda1_plot_c.txt','\t');
lambda1_plot_12_3ccr=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.640_lambda1_plot_ccr.txt','\t');

% lambda_delta=0.610 23之间
% type 0 SF-based
rho_plot_h_23_0ccl=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.610_h_ccl.txt','\t');
rho_plot_h_23_0c=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.610_h_c.txt','\t');
rho_plot_l_23_0c=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.610_l_c.txt','\t');
rho_plot_h_23_0ccr=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.610_h_ccr.txt','\t');
lambda1_plot_23_0ccl=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.610_lambda1_plot_ccl.txt','\t');
lambda1_plot_23_0c=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.610_lambda1_plot_c.txt','\t');
lambda1_plot_23_0ccr=load('N=2000_k1=20_k01=3_ode_lambda_delta=0.610_lambda1_plot_ccr.txt','\t');
% type 1 SF-based
rho_plot_h_23_1ccl=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.610_h_ccl.txt','\t');
rho_plot_h_23_1c=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.610_h_c.txt','\t');
rho_plot_l_23_1c=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.610_l_c.txt','\t');
rho_plot_h_23_1ccr=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.610_h_ccr.txt','\t');
lambda1_plot_23_1ccl=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.610_lambda1_plot_ccl.txt','\t');
lambda1_plot_23_1c=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.610_lambda1_plot_c.txt','\t');
lambda1_plot_23_1ccr=load('N=2000_k1=20_k11=3_ode_lambda_delta=0.610_lambda1_plot_ccr.txt','\t');
% type 2 SF-based
rho_plot_h_23_2cl=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.610_h_cl.txt','\t');
rho_plot_h_23_2=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.610_h_x.txt','\t');
rho_plot_h_23_2cr=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.610_h_cr.txt','\t');
rho_plot_l_23_2=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.610_l_x.txt','\t');
lambda1_plot_23_2cl=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.610_lambda1_plot_cl.txt','\t');
lambda1_plot_23_2=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.610_lambda1_plot_x.txt','\t');
lambda1_plot_23_2cr=load('N=2000_k1=20_k21=3_ode_lambda_delta=0.610_lambda1_plot_cr.txt','\t');
% type 3 SF-based
rho_plot_h_23_3cl=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.610_h_cl.txt','\t');
rho_plot_h_23_3=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.610_h_x.txt','\t');
rho_plot_h_23_3cr=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.610_h_cr.txt','\t');
rho_plot_l_23_3=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.610_l_x.txt','\t');
lambda1_plot_23_3cl=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.610_lambda1_plot_cl.txt','\t');
lambda1_plot_23_3=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.610_lambda1_plot_x.txt','\t');
lambda1_plot_23_3cr=load('N=2000_k1=20_k31=3_ode_lambda_delta=0.610_lambda1_plot_cr.txt','\t');


figure('Position', [100, 100, 750, 2000]);

ax1=subplot(3, 2, 1);
hold on;
h0=plot(ER_lambda1_plot_01_0ccl,ER_rho_plot_h_01_0ccl,'ko','DisplayName', 'type-0','MarkerSize',3);
plot(ER_lambda1_plot_01_0cl,ER_rho_plot_h_01_0cl,'ko','MarkerSize',3);
plot(ER_lambda1_plot_01_0,ER_rho_plot_h_01_0,'ko','MarkerSize',3);
plot(ER_lambda1_plot_01_0,ER_rho_plot_l_01_0,'ko','MarkerSize',3);
plot(ER_lambda1_plot_01_0cr,ER_rho_plot_h_01_0cr,'ko','MarkerSize',3);
plot(ER_lambda1_plot_01_0ccr,ER_rho_plot_h_01_0ccr,'ko','MarkerSize',3);

h1=plot(ER_lambda1_plot_01_1ccl,ER_rho_plot_h_01_1ccl,'b^','DisplayName', 'type-1','MarkerSize',3);
plot(ER_lambda1_plot_01_1cl,ER_rho_plot_h_01_1cl,'b^','MarkerSize',3);
plot(ER_lambda1_plot_01_1,ER_rho_plot_h_01_1,'b^','MarkerSize',3);
plot(ER_lambda1_plot_01_1,ER_rho_plot_l_01_1,'b^','MarkerSize',3);
plot(ER_lambda1_plot_01_1cr,ER_rho_plot_h_01_1cr,'b^','MarkerSize',3);
plot(ER_lambda1_plot_01_1ccr,ER_rho_plot_h_01_1ccr,'b^','MarkerSize',3);
plot(0.04737:0.00001:0.04738,[0,0.0946],'b--');
plot(0.04761:0.00001:0.04762,[0,0.1539],'b--');

h2=plot(ER_lambda1_plot_01_2ccl,ER_rho_plot_h_01_2ccl,'r+','DisplayName', 'type-2','MarkerSize',3);
plot(ER_lambda1_plot_01_2c,ER_rho_plot_h_01_2c,'r+','MarkerSize',3);
plot(ER_lambda1_plot_01_2c,ER_rho_plot_l_01_2c,'r+','MarkerSize',3);
plot(ER_lambda1_plot_01_2ccr,ER_rho_plot_h_01_2ccr,'r+','MarkerSize',3);
plot(0.04651:0.00001:0.04652,[0,0.1281],'r--');
plot(0.04723:0.00001:0.04724,[0,0.2055],'r--');

h3=plot(ER_lambda1_plot_01_3ccl,ER_rho_plot_h_01_3ccl,'gx','DisplayName', 'type-3','MarkerSize',3);
plot(ER_lambda1_plot_01_3c,ER_rho_plot_h_01_3c,'gx','MarkerSize',3);
plot(ER_lambda1_plot_01_3c,ER_rho_plot_l_01_3c,'gx','MarkerSize',3);
plot(ER_lambda1_plot_01_3ccr,ER_rho_plot_h_01_3ccr,'gx','MarkerSize',3);
plot(0.04575:0.00001:0.04576,[0,0.1369],'g--');
plot(0.04698:0.00001:0.04699,[0,0.2314],'g--');
box on;
axis([0.044 0.05 0 0.3]);
set(gca, 'FontName', 'Cambria Math'); % 设置字体
set(gca, 'FontSize', 16); % 设置字体大小
set(gca, 'LineWidth', 1); % 设置边框大小
title('(a)','FontSize',18);
xlabel('\lambda'), ylabel('\rho(\infty)')
xticks([0.044 0.046 0.048 0.05]); % 设置 x 轴刻度位置
% yticks([0.2 0.4 0.6]); % 设置 y 轴刻度位置
% legend('type-0','type-1','type-2','type-3','Location','northwest','Box','off');
% 小图
% inset_ax=axes('Position', [0.25, 0.63, 0.08, 0.16]); 
% hold on;
% plot(ER_lambda1_plot_01_0,ER_rho_plot_h_01_0,'k','LineWidth',1);
% plot(ER_lambda1_plot_01_0,ER_rho_plot_l_01_0,'k','LineWidth',1);
% plot(ER_lambda1_plot_01_1,ER_rho_plot_h_01_1,'r','LineWidth',1);
% plot(ER_lambda1_plot_01_1,ER_rho_plot_l_01_1,'r','LineWidth',1);
% plot(ER_lambda1_plot_01_0cr,ER_rho_plot_h_01_0cr,'k','LineWidth',1);
% plot(ER_lambda1_plot_01_1cr,ER_rho_plot_h_01_1cr,'r','LineWidth',1);
% box on;
% axis([0.04732 0.04764 0 0.2]);
% set(gca, 'FontSize', 10); 
% set(gca, 'LineWidth', 1);
% xticks([0.04732 0.04748 0.04764]); % 设置 x 轴刻度位置
% inset_ax.XAxis.TickDirection='in';  % X轴刻度朝外
% inset_ax.YAxis.TickDirection='in';  % Y轴刻度朝外
% inset_ax.TickLength=[0.02 0.05];  % [x轴长度比例, y轴长度比例]

ax2=subplot(3, 2, 2);
hold on;
plot(ER_lambda1_plot_12_0ccl,ER_rho_plot_h_12_0ccl,'ko','DisplayName', 'type-0','MarkerSize',3);
plot(ER_lambda1_plot_12_0c,ER_rho_plot_h_12_0c,'ko','MarkerSize',3);
plot(ER_lambda1_plot_12_0c,ER_rho_plot_l_12_0c,'ko','MarkerSize',3);
plot(ER_lambda1_plot_12_0ccr,ER_rho_plot_h_12_0ccr,'ko','MarkerSize',3);

plot(ER_lambda1_plot_12_1ccl,ER_rho_plot_h_12_1ccl,'b^','DisplayName', 'type-1','MarkerSize',3);
plot(ER_lambda1_plot_12_1cl,ER_rho_plot_h_12_1cl,'b^','MarkerSize',3);
plot(ER_lambda1_plot_12_1,ER_rho_plot_h_12_1,'b^','MarkerSize',3);
plot(ER_lambda1_plot_12_1,ER_rho_plot_l_12_1,'b^','MarkerSize',3);
plot(ER_lambda1_plot_12_1cr,ER_rho_plot_h_12_1cr,'b^','MarkerSize',3);
plot(ER_lambda1_plot_12_1ccr,ER_rho_plot_h_12_1ccr,'b^','MarkerSize',3);

plot(ER_lambda1_plot_12_2ccl,ER_rho_plot_h_12_2ccl,'r+','DisplayName', 'type-2','MarkerSize',3);
plot(ER_lambda1_plot_12_2cl,ER_rho_plot_h_12_2cl,'r+','MarkerSize',3);
plot(ER_lambda1_plot_12_2,ER_rho_plot_h_12_2,'r+','MarkerSize',3);
plot(ER_lambda1_plot_12_2cr,ER_rho_plot_h_12_2cr,'r+','MarkerSize',3);
plot(ER_lambda1_plot_12_2ccr,ER_rho_plot_h_12_2ccr,'r+','MarkerSize',3);
plot(ER_lambda1_plot_12_2,ER_rho_plot_l_12_2,'r+','MarkerSize',3);
plot(0.04708:0.00001:0.04709,[0,0.0657],'r--');
plot(0.04723:0.00001:0.04724,[0,0.1135],'r--');

plot(ER_lambda1_plot_12_3ccl,ER_rho_plot_h_12_3ccl,'gx','DisplayName', 'type-3','MarkerSize',3);
plot(ER_lambda1_plot_12_3c,ER_rho_plot_h_12_3c,'gx','MarkerSize',3);
plot(ER_lambda1_plot_12_3c,ER_rho_plot_l_12_3c,'gx','MarkerSize',3);
plot(ER_lambda1_plot_12_3ccr,ER_rho_plot_h_12_3ccr,'gx','MarkerSize',3);
plot(0.04650:0.00001:0.04651,[0,0.0953],'g--');
plot(0.04699:0.00001:0.04700,[0,0.1627],'g--');
box on;
axis([0.044 0.05 0 0.3]);
set(gca, 'FontName', 'Cambria Math'); % 设置字体
set(gca, 'FontSize', 16); % 设置字体大小
set(gca, 'LineWidth', 1); % 设置边框大小
title('(b)','FontSize',18);
xlabel('\lambda')
ylabel('\rho(\infty)')
xticks([0.044 0.046 0.048 0.05]); % 设置 x 轴刻度位置
% yticks([0.2 0.4 0.6]); % 设置 y 轴刻度位置
% legend('type-0','type-1','type-2','type-3','Location','northwest','Box','off');
% 小图
% inset_ax=axes('Position', [0.53, 0.63, 0.08, 0.16]); 
% hold on;
% plot(ER_lambda1_plot_12_1,ER_rho_plot_h_12_1,'k','LineWidth',1);
% plot(ER_lambda1_plot_12_1,ER_rho_plot_l_12_1,'k','LineWidth',1);
% plot(ER_lambda1_plot_12_2,ER_rho_plot_h_12_2,'r','LineWidth',1);
% plot(ER_lambda1_plot_12_2,ER_rho_plot_l_12_2,'r','LineWidth',1);
% plot(ER_lambda1_plot_12_1cl,ER_rho_plot_h_12_1cl,'k','LineWidth',1);
% plot(ER_lambda1_plot_12_2cr,ER_rho_plot_h_12_2cr,'r','LineWidth',1);
% box on;
% axis([0.04706 0.04770 0 0.2]);
% set(gca, 'FontSize', 10); 
% set(gca, 'LineWidth', 1);
% xticks([0.04706 0.04738 0.04770]); % 设置 x 轴刻度位置
% inset_ax.XAxis.TickDirection='in';  % X轴刻度朝外
% inset_ax.YAxis.TickDirection='in';  % Y轴刻度朝外
% inset_ax.TickLength=[0.02 0.05];  % [x轴长度比例, y轴长度比例]

ax3=subplot(3, 2, 3);
hold on;
plot(ER_lambda1_plot_23_0ccl,ER_rho_plot_h_23_0ccl,'ko','DisplayName', 'type-0','MarkerSize',3);
plot(ER_lambda1_plot_23_1ccl,ER_rho_plot_h_23_1ccl,'b^','DisplayName', 'type-1','MarkerSize',3);
plot(ER_lambda1_plot_23_2ccl,ER_rho_plot_h_23_2ccl,'r','DisplayName', 'type-2','MarkerSize',3);
plot(ER_lambda1_plot_23_3ccl,ER_rho_plot_h_23_3ccl,'g','DisplayName', 'type-3','MarkerSize',3);

plot(ER_lambda1_plot_23_0c,ER_rho_plot_h_23_0c,'ko','MarkerSize',3);
plot(ER_lambda1_plot_23_0c,ER_rho_plot_l_23_0c,'ko','MarkerSize',3,'MarkerSize',3);
plot(ER_lambda1_plot_23_0ccr,ER_rho_plot_h_23_0ccr,'ko','MarkerSize',3);

plot(ER_lambda1_plot_23_1c,ER_rho_plot_h_23_1c,'b^','MarkerSize',3);
plot(ER_lambda1_plot_23_1c,ER_rho_plot_l_23_1c,'b^','MarkerSize',3);
plot(ER_lambda1_plot_23_1ccr,ER_rho_plot_h_23_1ccr,'b^','MarkerSize',3);

plot(ER_lambda1_plot_23_2cl,ER_rho_plot_h_23_2cl,'r+','MarkerSize',3);
plot(ER_lambda1_plot_23_2,ER_rho_plot_h_23_2,'r+','MarkerSize',3);
plot(ER_lambda1_plot_23_2,ER_rho_plot_l_23_2,'r+','MarkerSize',3);
plot(ER_lambda1_plot_23_2cr,ER_rho_plot_h_23_2cr,'r+','MarkerSize',3);
plot(ER_lambda1_plot_23_2ccr,ER_rho_plot_h_23_2ccr,'r+','MarkerSize',3);

plot(ER_lambda1_plot_23_3cl,ER_rho_plot_h_23_3cl,'gx','MarkerSize',3);
plot(ER_lambda1_plot_23_3,ER_rho_plot_h_23_3,'gx','MarkerSize',3);
plot(ER_lambda1_plot_23_3,ER_rho_plot_l_23_3,'gx','MarkerSize',3);
plot(ER_lambda1_plot_23_3cr,ER_rho_plot_h_23_3cr,'gx','MarkerSize',3);
plot(ER_lambda1_plot_23_3ccr,ER_rho_plot_h_23_3ccr,'gx','MarkerSize',3);
plot(0.04688:0.00001:0.04689,[0,0.0483],'g--');
plot(0.04698:0.00001:0.04699,[0,0.0837],'g--');
box on;
axis([0.044 0.05 0 0.3]);
set(gca, 'FontName', 'Cambria Math'); % 设置字体
set(gca, 'FontSize', 16); % 设置字体大小
set(gca, 'LineWidth', 1); % 设置边框大小
title('(c)','FontSize',18);
xlabel('\lambda')
ylabel('\rho(\infty)')
xticks([0.044 0.046 0.048 0.05]); % 设置 x 轴刻度位置
% yticks([0.2 0.4 0.6]); % 设置 y 轴刻度位置
% legend('type-0','type-1','type-2','type-3','Location','northwest','Box','off');
% 小图
% inset_ax=axes('Position', [0.81, 0.63, 0.08, 0.16]); 
% hold on;
% plot(ER_lambda1_plot_23_2,ER_rho_plot_h_23_2,'k','LineWidth',1);
% plot(ER_lambda1_plot_23_2,ER_rho_plot_l_23_2,'k','LineWidth',1);
% plot(ER_lambda1_plot_23_3,ER_rho_plot_h_23_3,'r','LineWidth',1);
% plot(ER_lambda1_plot_23_3,ER_rho_plot_l_23_3,'r','LineWidth',1);
% plot(ER_lambda1_plot_23_2cl,ER_rho_plot_h_23_2cl,'k','LineWidth',1);
% plot(ER_lambda1_plot_23_3cr,ER_rho_plot_h_23_3cr,'r','LineWidth',1);
% box on;
% axis([0.04686 0.04730 0 0.2]);
% set(gca, 'FontSize', 10); 
% set(gca, 'LineWidth', 1);
% xticks([0.04686 0.04708 0.04730]); % 设置 x 轴刻度位置
% inset_ax.XAxis.TickDirection='in';  % X轴刻度朝外
% inset_ax.YAxis.TickDirection='in';  % Y轴刻度朝外
% inset_ax.TickLength=[0.02 0.05];  % [x轴长度比例, y轴长度比例]


ax4=subplot(3, 2, 4);
hold on;
plot(lambda1_plot_01_0cl,rho_plot_h_01_0cl,'ko','DisplayName', 'type-0','MarkerSize',3);
plot(lambda1_plot_01_1cl,rho_plot_h_01_1cl,'b^','DisplayName', 'type-1','MarkerSize',3);
plot(lambda1_plot_01_2ccl,rho_plot_h_01_2ccl,'r+','DisplayName', 'type-2','MarkerSize',3);
plot(lambda1_plot_01_3ccl,rho_plot_h_01_3ccl,'gx','DisplayName', 'type-3','MarkerSize',3);

plot(lambda1_plot_01_0,rho_plot_h_01_0,'ko','MarkerSize',3);
plot(lambda1_plot_01_0,rho_plot_l_01_0,'ko','MarkerSize',3);
plot(lambda1_plot_01_0cr,rho_plot_h_01_0cr,'ko','MarkerSize',3);

plot(lambda1_plot_01_1,rho_plot_h_01_1,'b^','MarkerSize',3);
plot(lambda1_plot_01_1,rho_plot_l_01_1,'b^','MarkerSize',3);
plot(lambda1_plot_01_1cr,rho_plot_h_01_1cr,'b^','MarkerSize',3);
plot(0.03118:0.00001:0.03119,[0.0973,0.2493],'b--');
plot(0.03151:0.00001:0.03152,[0.1370,0.2915],'b--');


plot(lambda1_plot_01_2c,rho_plot_h_01_2c,'r+','MarkerSize',3);
plot(lambda1_plot_01_2c,rho_plot_l_01_2c,'r+','MarkerSize',3);
plot(lambda1_plot_01_2ccr,rho_plot_h_01_2ccr,'r+','MarkerSize',3);
plot(0.03108:0.00001:0.03109,[0.0515,0.2537],'r--');
plot(0.03201:0.00001:0.03202,[0.1083,0.3210],'r--');

plot(lambda1_plot_01_3c,rho_plot_h_01_3c,'gx','MarkerSize',3);
plot(lambda1_plot_01_3c,rho_plot_l_01_3c,'gx','MarkerSize',3);
plot(lambda1_plot_01_3ccr,rho_plot_h_01_3ccr,'gx','MarkerSize',3);
plot(0.03023:0.00001:0.03024,[0.0026,0.2619],'g--');
plot(0.03281:0.00001:0.03282,[0.0692,0.3657],'g--');
box on;
axis([0.024 0.036 0 0.45]);
set(gca, 'FontName', 'Cambria Math'); % 设置字体
set(gca, 'FontSize', 16); % 设置字体大小
set(gca, 'LineWidth', 1); % 设置边框大小
title('(d)','FontSize',18);
xlabel('\lambda')
ylabel('\rho(\infty)')
xticks([0.024 0.028 0.032 0.036]); % 设置 x 轴刻度位置
yticks([0.15 0.3 0.45]); % 设置 y 轴刻度位置
% legend('type-0','type-1','type-2','type-3','Location','northwest','Box','off');
% 小图
% inset_ax=axes('Position', [0.25, 0.155, 0.08, 0.16]); 
% hold on;
% plot(lambda1_plot_01_0cl,rho_plot_h_01_0cl,'k','LineWidth',1);
% plot(lambda1_plot_01_1cl,rho_plot_h_01_1cl,'r','LineWidth',1);
% plot(lambda1_plot_01_0,rho_plot_h_01_0,'k','LineWidth',1);
% plot(lambda1_plot_01_1,rho_plot_h_01_1,'r','LineWidth',1);
% plot(lambda1_plot_01_0cr,rho_plot_h_01_0cr,'k','LineWidth',1);
% plot(lambda1_plot_01_1cr,rho_plot_h_01_1cr,'r','LineWidth',1);
% plot(lambda1_plot_01_0,rho_plot_l_01_0,'k','LineWidth',1);
% plot(lambda1_plot_01_1,rho_plot_l_01_1,'r','LineWidth',1);
% box on;
% axis([0.03100 0.03200 0 0.4]);
% set(gca, 'FontSize', 10); 
% set(gca, 'LineWidth', 1);
% xticks([0.03100 0.03150 0.03200]); % 设置 x 轴刻度位置
% inset_ax.XAxis.TickDirection='in';  % X轴刻度朝外
% inset_ax.YAxis.TickDirection='in';  % Y轴刻度朝外
% inset_ax.TickLength=[0.02 0.05];  % [x轴长度比例, y轴长度比例]

ax5=subplot(3, 2, 5);
hold on;
plot(lambda1_plot_12_0ccl,rho_plot_h_12_0ccl,'ko','DisplayName', 'type-0','MarkerSize',3);
plot(lambda1_plot_12_1cl,rho_plot_h_12_1cl,'b^','DisplayName', 'type-1','MarkerSize',3);
plot(lambda1_plot_12_2cl,rho_plot_h_12_2cl,'r+','DisplayName', 'type-2','MarkerSize',3);
plot(lambda1_plot_12_3ccl,rho_plot_h_12_3ccl,'gx','DisplayName', 'type-3','MarkerSize',3);

plot(lambda1_plot_12_0c,rho_plot_h_12_0c,'ko','MarkerSize',3);
plot(lambda1_plot_12_0c,rho_plot_l_12_0c,'ko','MarkerSize',3);
plot(lambda1_plot_12_0ccr,rho_plot_h_12_0ccr,'ko','MarkerSize',3);

plot(lambda1_plot_12_1,rho_plot_h_12_1,'b^','MarkerSize',3);
plot(lambda1_plot_12_1,rho_plot_l_12_1,'b^','MarkerSize',3);
plot(lambda1_plot_12_1cr,rho_plot_h_12_1cr,'b^','MarkerSize',3);

plot(lambda1_plot_12_2,rho_plot_h_12_2,'r+','MarkerSize',3);
plot(lambda1_plot_12_2,rho_plot_l_12_2,'r+','MarkerSize',3);
plot(lambda1_plot_12_2cr,rho_plot_h_12_2cr,'r+','MarkerSize',3);
plot(0.03221:0.00001:0.03222,[0.0898,0.2286],'r--');
plot(0.03248:0.00001:0.03249,[0.1241,0.2712],'r--');

plot(lambda1_plot_12_3c,rho_plot_h_12_3c,'gx','MarkerSize',3);
plot(lambda1_plot_12_3c,rho_plot_l_12_3c,'gx','MarkerSize',3);
plot(lambda1_plot_12_3ccr,rho_plot_h_12_3ccr,'gx','MarkerSize',3);
plot(0.03149:0.00001:0.03150,[0.0186,0.2450],'g--');
plot(0.03311:0.00001:0.03312,[0.0803,0.3341],'g--');
box on;
axis([0.024 0.036 0 0.45]);
set(gca, 'FontName', 'Cambria Math'); % 设置字体
set(gca, 'FontSize', 16); % 设置字体大小
set(gca, 'LineWidth', 1); % 设置边框大小
title('(e)','FontSize',18);
xlabel('\lambda')
ylabel('\rho(\infty)')
xticks([0.024 0.028 0.032 0.036]); % 设置 x 轴刻度位置
yticks([0.15 0.3 0.45]); % 设置 y 轴刻度位置
% legend('type-0','type-1','type-2','type-3','Location','northwest','Box','off');
% 小图
% inset_ax=axes('Position', [0.53, 0.155, 0.08, 0.16]); 
% hold on;
% plot(lambda1_plot_12_1cl,rho_plot_h_12_1cl,'k','LineWidth',1);
% plot(lambda1_plot_12_2cl,rho_plot_h_12_2cl,'r','LineWidth',1);
% plot(lambda1_plot_12_1,rho_plot_h_12_1,'k','LineWidth',1);
% plot(lambda1_plot_12_2,rho_plot_h_12_2,'r','LineWidth',1);
% plot(lambda1_plot_12_1cr,rho_plot_h_12_1cr,'k','LineWidth',1);
% plot(lambda1_plot_12_2cr,rho_plot_h_12_2cr,'r','LineWidth',1);
% plot(lambda1_plot_12_1,rho_plot_l_12_1,'k','LineWidth',1);
% plot(lambda1_plot_12_2,rho_plot_l_12_2,'r','LineWidth',1);
% box on;
% axis([0.03200 0.03300 0 0.4]);
% set(gca, 'FontSize', 10); 
% set(gca, 'LineWidth', 1);
% xticks([0.03200 0.03250 0.03300]); % 设置 x 轴刻度位置
% inset_ax.XAxis.TickDirection='in';  % X轴刻度朝外
% inset_ax.YAxis.TickDirection='in';  % Y轴刻度朝外
% inset_ax.TickLength=[0.02 0.05];  % [x轴长度比例, y轴长度比例]

ax6=subplot(3, 2, 6);
hold on;
plot(lambda1_plot_23_0ccl,rho_plot_h_23_0ccl,'ko','DisplayName', 'type-0','MarkerSize',3);
plot(lambda1_plot_23_1ccl,rho_plot_h_23_1ccl,'b^','DisplayName', 'type-1','MarkerSize',3);
plot(lambda1_plot_23_2cl,rho_plot_h_23_2cl,'r+','DisplayName', 'type-2','MarkerSize',3);
plot(lambda1_plot_23_3cl,rho_plot_h_23_3cl,'gx','DisplayName', 'type-3','MarkerSize',3);

plot(lambda1_plot_23_0c,rho_plot_h_23_0c,'ko','MarkerSize',3);
plot(lambda1_plot_23_0c,rho_plot_l_23_0c,'ko','MarkerSize',3);
plot(lambda1_plot_23_0ccr,rho_plot_h_23_0ccr,'ko','MarkerSize',3);

plot(lambda1_plot_23_1c,rho_plot_h_23_1c,'b^','MarkerSize',3);
plot(lambda1_plot_23_1c,rho_plot_l_23_1c,'b^','MarkerSize',3);
plot(lambda1_plot_23_1ccr,rho_plot_h_23_1ccr,'b^','MarkerSize',3);

plot(lambda1_plot_23_2,rho_plot_h_23_2,'r+','MarkerSize',3);
plot(lambda1_plot_23_2,rho_plot_l_23_2,'r+','MarkerSize',3);
plot(lambda1_plot_23_2cr,rho_plot_h_23_2cr,'r+','MarkerSize',3);

plot(lambda1_plot_23_3,rho_plot_h_23_3,'gx','MarkerSize',3);
plot(lambda1_plot_23_3,rho_plot_l_23_3,'gx','MarkerSize',3);
plot(lambda1_plot_23_3cr,rho_plot_h_23_3cr,'gx','MarkerSize',3);
plot(0.03287:0.00001:0.03288,[0.0474,0.2266],'g--');
plot(0.03353:0.00001:0.03354,[0.0936,0.2862],'g--');
box on;
axis([0.024 0.036 0 0.45]);
set(gca, 'FontName', 'Cambria Math'); % 设置字体
set(gca, 'FontSize', 16); % 设置字体大小
set(gca, 'LineWidth', 1); % 设置边框大小
title('(f)','FontSize',18);
xlabel('\lambda')
ylabel('\rho(\infty)')
xticks([0.024 0.028 0.032 0.036]); % 设置 x 轴刻度位置
yticks([0.15 0.3 0.45]); % 设置 y 轴刻度位置
% legend('type-0','type-1','type-2','type-3','Location','northwest','Box','off');
% 小图
% inset_ax=axes('Position', [0.81, 0.155, 0.08, 0.16]); 
% hold on;
% plot(lambda1_plot_23_2cl,rho_plot_h_23_2cl,'k','LineWidth',1);
% plot(lambda1_plot_23_3cl,rho_plot_h_23_3cl,'r','LineWidth',1);
% plot(lambda1_plot_23_2,rho_plot_h_23_2,'k','LineWidth',1);
% plot(lambda1_plot_23_3,rho_plot_h_23_3,'r','LineWidth',1);
% plot(lambda1_plot_23_2cr,rho_plot_h_23_2cr,'k','LineWidth',1);
% plot(lambda1_plot_23_3cr,rho_plot_h_23_3cr,'r','LineWidth',1);
% plot(lambda1_plot_23_2,rho_plot_l_23_2,'k','LineWidth',1);
% plot(lambda1_plot_23_3,rho_plot_l_23_3,'r','LineWidth',1);
% box on;
% axis([0.03200 0.03400 0 0.4]);
% set(gca, 'FontSize', 10); 
% set(gca, 'LineWidth', 1);
% xticks([0.03200 0.03300 0.03400]); % 设置 x 轴刻度位置
% inset_ax.XAxis.TickDirection='in';  % X轴刻度朝外
% inset_ax.YAxis.TickDirection='in';  % Y轴刻度朝外
% inset_ax.TickLength=[0.02 0.05];  % [x轴长度比例, y轴长度比例]

%调整子图位置
pos3 = ax3.Position; 
ax3.Position = [pos3(1), pos3(2)-0.02, pos3(3), pos3(4)]; 
pos4 = ax4.Position; 
ax4.Position = [pos4(1), pos4(2)-0.02, pos4(3), pos4(4)]; 
pos5 = ax5.Position; 
ax5.Position = [pos5(1), pos5(2)-0.04, pos5(3), pos5(4)]; 
pos6 = ax6.Position; 
ax6.Position = [pos6(1), pos6(2)-0.04, pos6(3), pos6(4)]; 

monitors = get(0, 'MonitorPositions');  % 获取显示器信息
primary_mon = monitors(1, :);           % 第一个显示器
new_width = 750;
new_height = 2000;
new_x = primary_mon(1) + (primary_mon(3) - new_width)/2;
new_y = primary_mon(2) + (primary_mon(4) - new_height)/2;
set(gcf, 'Position', [new_x, new_y, new_width, new_height]);

fig = gcf;
figPos = fig.Position;  % [左, 下, 宽, 高]

% legend([h0, h1, h2, h3], 'Location', 'northeastoutside'); % 将图注放在图形外侧
leg = legend([h0, h1, h2, h3]); 
set(leg, 'Units', 'normalized', 'Position', [0.92, 0.5, 0.01, 0.02]);
% leg.Layout.Tile = 'east'; % 将图注放在布局右侧

allAxes = findobj(fig, 'Type', 'axes', '-not', 'Tag', 'legend');
% 调整每个坐标轴宽度（缩小15%给图注腾空间）
for i = 1:length(allAxes)
    axPos = get(allAxes(i), 'Position');
    set(allAxes(i), 'Position', [axPos(1), axPos(2), axPos(3)*0.85, axPos(4)]);
end